package kr.or.ddit.common.vo;

public class CodeVO {
	private String GroupCode;
	private String GroupCodeName;
	private String Code;
	private String CodeName;
	private String Description;
	private String UseYn;
	
	
	
	@Override
	public String toString() {
		return "CodeVO [GroupCode=" + GroupCode + ", GroupCodeName=" + GroupCodeName + ", Code=" + Code + ", CodeName="
				+ CodeName + ", Description=" + Description + ", UseYn=" + UseYn + "]";
	}
	public String getGroupCode() {
		return GroupCode;
	}
	public void setGroupCode(String groupCode) {
		GroupCode = groupCode;
	}
	public String getGroupCodeName() {
		return GroupCodeName;
	}
	public void setGroupCodeName(String groupCodeName) {
		GroupCodeName = groupCodeName;
	}
	public String getCode() {
		return Code;
	}
	public void setCode(String code) {
		Code = code;
	}
	public String getCodeName() {
		return CodeName;
	}
	public void setCodeName(String codeName) {
		CodeName = codeName;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getUseYn() {
		return UseYn;
	}
	public void setUseYn(String useYn) {
		UseYn = useYn;
	}
}
