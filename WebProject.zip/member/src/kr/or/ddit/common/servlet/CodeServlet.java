package kr.or.ddit.common.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.common.service.CodeService;
import kr.or.ddit.common.vo.CodeVO;


@WebServlet("/CodeServlet")
public class CodeServlet extends HttpServlet {
   private static final long serialVersionUID = 7428836381231581524L;
   
   //GET방식 호출 시
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   request.setCharacterEncoding("UTF-8");
   }
   
   //POST방식 호출 시
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("UTF-8");

      retrieveCodeList(request, response);
      
   }
   
   private void retrieveCodeList(HttpServletRequest request, HttpServletResponse response) {
      try {  
    	  
         CodeVO codeVo = new CodeVO();
         codeVo.setGroupCode(request.getParameter("groupCode"));   //가지고올때
         
         CodeService service = new CodeService();
         List<CodeVO> list = service.retrieveCodeList(codeVo);
         
         request.setAttribute("list", list);   
         
         RequestDispatcher disp = request.getRequestDispatcher("/html/member/codeList.jsp");  //""이 화면으로 request를 다시 보낸다.
         disp.forward(request, response);
         
      } catch (ServletException | IOException e) {
         e.printStackTrace();
      } catch (Exception e1) {
         e1.printStackTrace();
      }
   }
}