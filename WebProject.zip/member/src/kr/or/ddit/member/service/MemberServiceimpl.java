package kr.or.ddit.member.service;

import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoimpl;
import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.member.vo.ZipVO;

/*
 	Dao객체 얻어오기 => dao 메서드 호출하기
 	자신의 service 객체를 생성하고 리턴하기 - controller에서 사용
 	
 */
public class MemberServiceimpl implements IMemberService{
	
	private IMemberDao dao;
	private static IMemberService service;
	
	private MemberServiceimpl() { // 다오 얻어오기
		dao = MemberDaoimpl.getDao();
	
	}
	
	public static IMemberService getService() { // 서비스가 없을때만 생성 있으면 리턴
		if(service == null) {
			service = new MemberServiceimpl();
		}
		
		return service;
	}
	
	@Override
	public List<MemberVO> selectAll() {
	
		List<MemberVO> memlist = null;
		
		try {
			memlist = dao.selectAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return memlist;
	}

	
	
	@Override
	public String checkById(String id) {
		
		String memid= null;
		
		try {
			memid = dao.checkById(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return memid;
	}

	@Override
	public List<ZipVO> selectByDong(String dong) {
		
		List<ZipVO> list = null;
		
		try {
			list = dao.selectByDong(dong);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public String insertMember(MemberVO vo) {
		
		String savaId = null;
		
		try {
			savaId = dao.insertMember(vo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return savaId;
	}
	
}
