package kr.or.ddit.member.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceimpl;
import kr.or.ddit.member.vo.MemberVO;

/**
 * Servlet implementation class Insert
 */
@WebServlet("/InsertSignUp")
public class InsertSignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertSignUp() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		MemberVO vo = new MemberVO();
		
		try {
			BeanUtils.populate(vo, request.getParameterMap());
			
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
		
		//1. 클라이언트 요청시 전송하는 값 받기
//		String mem_id = request.getParameter("mem_id");
//		String mem_name = request.getParameter("mem_name");
//		String mem_pass = request.getParameter("mem_pass");
//		String mem_bir = request.getParameter("mem_bir");
//		String mem_mail = request.getParameter("mem_mail");
//		String mem_zip = request.getParameter("mem_zip");
//		String mem_hp = request.getParameter("mem_hp");
//		String mem_add1 = request.getParameter("mem_add1");
//		String mem_add2 = request.getParameter("mem_add2");
//		
//		MemberVO vo = new MemberVO();
//		vo.setMem_id(mem_id);
//		vo.setMem_name(mem_name);
//		vo.setMem_pass(mem_pass);
//		vo.setMem_add1(mem_add1);
//		vo.setMem_add2(mem_add2);
//		vo.setMem_hp(mem_hp);
//		vo.setMem_bir(mem_bir);
//		vo.setMem_zip(mem_zip);
//		vo.setMem_mail(mem_mail);
		
		
		//2. service 객체 얻기
		IMemberService service = MemberServiceimpl.getService();
		
		//3. 메소드 호출
		String saveId = service.insertMember(vo);
		
		//4. request에 저장
		request.setAttribute("saveId", saveId);
		
		//5.jsp
		request.getRequestDispatcher("/html/member/InsertForm.jsp").forward(request, response);
		
		
		
		
	}

}
