/**
 * 공통 기능 모음 - 많이 쓰는 함수들
 */


function getParamByLocation(){
	
}

function isEmpty(val){
	if(val == underfined) return true;
	
	if(val.trim().length ==0 || val == null)  return true;
}