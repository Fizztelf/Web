/**
 * 공통 기능 모음 - 많이 쓰는 함수들
 */

function getParamByLocation(sname) {
	var svalue = "";
	
	var param = location.search.substr(location.search.indexOf("?") + 1);
	param = decodeURI(param);
	console.log(param);
	
	var arr = param.split("&");
	for(var i = 0 ; i < arr.length ; i++){
		var arrTmp = arr[i].split("=");
		if(arrTmp[0] == sname) {
			console.log(arrTmp[0]);
			svalue = arrTmp[1];
			break;
		}
	}
	
	return svalue;
}

function isEmpty(val) {
	if(val == undefined) return true;
	if(val.trim().length == 0 
			|| val == null)
		return true;
}

function formatHpno(val) {
	if(val == null || val == undefined)
		return val;
	
	val = val.replaceAll("-", "");
	
	//1)숫자로만 10자리, 11자리가 입력된게 맞는지 확인
	//2)맞다면 ***-****-**** 또는 ***-***-**** 로 변경해서 리턴
	var regExp = /^(\d{10,11})$/;
	if( regExp.test(val) ) { //1)
		//2)
		return val.replace(/(\d{3})(\d{3,4})(\d{4})/, "$1-$2-$3" );
	} else {
		return val;
	}
	
}






//[수정중]post로 보낸 경우 데이터 가져오는 방법은?
function postParam(sname) {
	var req = new XMLHttpRequest();
	console.log(req);
	console.log(document.location);
	req.open("GET", document.location, false);
	var header = req.getAllResponseHeaders();
	console.log(header+"-------------------");
	//req.send(null);
	req.abort();
}