/*
VERSION: 0.5.0
 [TABLE OF CONTENT]
 1) preloader
 2) browser title(접근성 문서제목)
 3) uiLayoutload (gnb, sidebar, footer load - 개발시 삭제)
 4) sidebar event(좌측메뉴)
 5) fileAttach (파일첨부)
 6) scroll Table(테이블 두개로 만들어진 그리드)
 7) daterangepicker
 8) btn-toggle (검색영역 열고 닫기)
 9) open window popup / close window popup
 10) input 내 로딩
 11) table sorting
 */

$(function(){
    /*-------------------------------------------------------------------------------
    1) preloader js
    -------------------------------------------------------------------------------*/
    function loader() {
        $(window).on('load', function () {
            var loadHtml = "<div class='loader'><div class='inner'><h3>" + "잠시만 기다려주세요" + "</h3><div class='item'></div></div></div>";
            $('.preloader').html(loadHtml);
            $('.loader').addClass('loaded');

            if ($('.loader').hasClass('loaded')) {
                $('.loader').delay(900).queue(function () {
                    $(this).remove();
                });
            }
        });
    }
    loader();

    /*-------------------------------------------------------------------------------
        2) browser title js
    -------------------------------------------------------------------------------*/
    if($(document).find('.page-header').length !== 0){
        var title = $(".page-header h3").text();
        document.title = title + " | 시스템명";
    };

    /*-------------------------------------------------------------------------------
        3) uiLayoutLoad js (GNB, SIDEBAR, FOOTER)
    -------------------------------------------------------------------------------*/
    function uiLayoutLoad(){
        $("#header").load("../html/include/header.html");
        $("#sidebar").load("../html/include/sidebar.html", function(){sidebarEvent()});
        $("footer").load("../html/include/footer.html");
    }
    uiLayoutLoad();

    /*-------------------------------------------------------------------------------
        4) sidebarEvent js 레프트메뉴
    -------------------------------------------------------------------------------*/
    function sidebarEvent(){
        $('.lnb-menu>li:has(ul)').addClass("has-sub");
        $('.lnb-menu>li>a').on("click", function() {

            var checkElement = $(this).next();

            if($(".lnb-menu").hasClass('toggle')){
                $('.lnb-menu>li').removeClass('active');
                $('.lnb-menu ul').slideUp('normal');
                $(this).closest('li').addClass('active');
                if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
                    checkElement.slideUp('normal');
                }
                if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                    $('.lnb-menu.toggle ul:visible').slideUp('normal');
                    checkElement.slideDown('normal');
                    $(this).closest('li').addClass('active');
                } else {
                    return true;
                }
            }
        });

        /* 메뉴 모두 펼치기 */
        $('.switch').val(this.checked);

        $(".switch").change(function(){
            if(this.checked){
                $('.lnb-menu').removeClass("toggle");
                $('.lnb-menu ul').slideDown('normal');
                $('.lnb-menu li').removeClass('active');
            } else {
                $('.lnb-menu').addClass("toggle");
                $('.lnb-menu ul').slideUp('normal');
                $(".current").addClass('active').parent("ul").slideDown();
                
            }
        }); 

        $(".lnb").mCustomScrollbar({
            theme:"minimal", //테마
            mouseWheelPixels : 50, // 마우스휠 속도
            scrollInertia : 400 // 부드러운 스크롤 효과 적용
        });

        /* 현재페이지 표시(개발시 삭제) */
        var loc = window.location.pathname;
        var _pageCurrent = $('.lnb-menu a[href="'+loc+'"]').parents('li').addClass('current active').parent('ul').show();    
    }
    sidebarEvent();

    /*-------------------------------------------------------------------------------
        5) fileAttach js 파일첨부
    -------------------------------------------------------------------------------*/  
    $('.dFile').on('click', function(){
        var $fName = $(this).find('.file-name'),
            $inputFile = $(this).find('.input-file'),
            $fDelete = $(this).find('.file-delete'),
            $fSize = $(this).find('.file-size');

        $inputFile.on('change',function(e){

            fileName = this.files[0].name;
            iSize = this.files[0].size / 1024;

            if(iSize/1024 > 1){
                if(((iSize/1024)/1024)>1){
                    iSize = (Math.round(((iSize/1024)/1024)*100)/100);
                    fileSize = iSize + "GB"
                } else {
                    iSize = (Math.round((iSize/1024)*100)/100);
                    fileSize = iSize + "MB"
                }
            } else {
                iSize = (Math.round(iSize*100)/100);
                fileSize = iSize + "KB"
            }
            $fName.text(fileName);
            $fDelete.show();
            
            $fSize.text(fileSize).show();
            $fName.addClass("off");
        });

        $fDelete.on('click', function(){
            $inputFile.val("");
            $fName.text("");
            $fDelete.hide();
            $fSize.hide();
            $fName.removeClass("off");
        })
    });

    /*-------------------------------------------------------------------------------
        6) scrollTable js 
    -------------------------------------------------------------------------------*/ 
    function scrollTable(){
        $(".table-header").each(function(){
            var theadH = $(this).outerHeight();
            $(this).next(".table-body").css("padding-top", theadH);
            $(this).next(".table-body").mCustomScrollbar({
                theme:"minimal-dark", //테마
                mouseWheelPixels : 50, // 마우스휠 속도
                scrollInertia : 400 // 부드러운 스크롤 효과 적용
            });
        })
    };

    if($(".table-header").length > 0 ){
        scrollTable();
    };    

    /*-------------------------------------------------------------------------------
        7) daterangepicker
    -------------------------------------------------------------------------------*/
    if($(".singleDate").length > 0){
        $(".singleDate").daterangepicker({
            singleDatePicker: true,
            format: 'YYYY/MM/DD',
        });
    }

    if($(".bothDate").length > 0){
        $(".bothDate").daterangepicker({
            format: 'YYYY/MM/DD',
        });
    }

    /*-------------------------------------------------------------------------------
        8) btn-toggle js / 검색영역 열고 닫기
    -------------------------------------------------------------------------------*/
    $(".btn-toggle").on("click",function(){
        if(!$(".layout2").hasClass("search-hide")){
            $(".layout2").addClass("search-hide");
            $(".btn-toggle").find("i").removeClass("ico-left").addClass("ico-search-w")
        } else {
            $(".layout2").removeClass("search-hide");
            $(".btn-toggle").find("i").removeClass("ico-search-w").addClass("ico-left")
        }
    });
    
    /*-------------------------------------------------------------------------------
        9) open window popup / close window popup
    -------------------------------------------------------------------------------*/
    $(".winPop").on("click",function(e){
        e.preventDefault();
        var href = $(this).attr("href"),
            width = $(this).attr("data-width"),
            height = $(this).attr("data-height"),
            winPop = window.open(href, "winPop", "height=" + height + ",width=" + width + ", menubar=no, toolbar=no");
    });

    $(".popup .btn-popup-close").on("click",function(){
        window.close();
    });
    
    /*-------------------------------------------------------------------------------
        10) input 내 로딩
    -------------------------------------------------------------------------------*/
    function spinnerRemove(){
        $(".spinner").remove();
    }
    
    $(".btnSpinner").on("click",function(){
        spinnerRemove();
        $(this).parent(".input-group").append("<i class='spinner'></i>")
    });

    /*-------------------------------------------------------------------------------
        11) tip (tooltip)
    -------------------------------------------------------------------------------*/
    if($(".tip").length > 0){
        $(".tip").hint();
    };

    /*-------------------------------------------------------------------------------
        12) sortable table js
    -------------------------------------------------------------------------------*/
    $('.sortable th').each(function (column) {
        $(this).click(function(){
            if($(this).hasClass("sorting")){
                if($(this).is('.asc')){
                    $(this).removeClass('asc');
                    $(this).addClass('desc');
                    sortdir=-1;
                } else {
                    $(this).addClass('asc');
                    $(this).removeClass('desc');
                    sortdir=1;
                }

                $(this).siblings().removeClass('asc');
                $(this).siblings().removeClass('desc');
                
                var rec = $(this).parents("table").find('tbody>tr').get();

                rec.sort(function (a, b) {
                    var val1 = $(a).children('td').eq(column).text();
                    var val2 = $(b).children('td').eq(column).text();
                    return (val1 < val2)?-sortdir:(val1>val2)?sortdir:0;
                });
                $.each(rec, function(index, row) {
                    $(this).parents('table').find('tbody').append(row);
                });
            }

            //column highlighted
            $(this).parents("table").find('td').removeClass('highlighted');
            var t = parseInt($(this).index()) + 1;
            $(this).parents('table').find($('td:nth-child(' + t + ')')).addClass('highlighted');
        });
    });

})
