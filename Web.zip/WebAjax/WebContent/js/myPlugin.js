/*
VERSION: 0.5.0
 [TABLE OF CONTENT]
 1) modal plugin
 2) tabMenu plugin
 3) accordion plugin
 4) hit(tooltip) plugin
 */

(function($){
    /*-------------------------------------------------------------------------------
        1) modal js plugin
    -------------------------------------------------------------------------------*/
    $.fn.modalBox = function(prop){
        var option = $.extend({
            title : "",
            type : "",
            size : "",
            height : "",
            page : "",
            scrollbar : true
        },prop);

        var self = this;

        return self.click(function(e){
            e.preventDefault();
            addModal();
            addStyle();            
            $("body").addClass("open-modal");            
        });

        function addModal(){
            var popup = $("<div class='modal "+ option.type + "'><div class='modal-header'><h3>"+ option.title +"</h3><button type='button' class='btn-modal-close closeModal'></button></div><div class='modal-body'><div class='modal-content'></div></div></div>");
            var backdrop = $("<div class='backdrop'></div>");
            $("body").append(backdrop).fadeIn();
            $("body").append(popup);
            $("body").removeClass("open-modal");

            $(".modal-content").load(option.page);
            $.getScript("../js/ui.js");
            if (option.scrollbar){
                $(".modal-body").mCustomScrollbar({
                    theme:"minimal-dark", //테마
                    mouseWheelPixels : 100, // 마우스휠 속도
                    autoHideScrollbar: false
                });
            }           
            
            $('.closeModal:first').focus();
            $(document).on("click",".closeModal, .backdrop", function(){
                $("body").removeClass("open-modal");
                $(".modal, .backdrop").remove();
                self.focus();
                return
            })
            
        }

        function addStyle(){
            $('.modal .inner').css({
                'height':(option.height) + 'px',
                'width':(option.width) + 'px',
            });            
        }

        return this;
    }

    /*-------------------------------------------------------------------------------
        2) tabsMenu js plugin
    -------------------------------------------------------------------------------*/
    $.fn.tabMenu = function(option){
        var option = $.extend({
            content : "" //tab content class 내용
        }, option);

        return this.find("a").on("click",function(e){
            e.preventDefault();
            $(this).closest("li").addClass("active").append("<span class='sr-only'>현재 탭</span>").siblings().removeClass("active").find(".sr-only").remove();

            var tabpanId = $(this).attr("href");
            var $tabpan = $(tabpanId);
            

            $(option.content).not($tabpan).removeClass("show");
            $tabpan.addClass('show');
            return false;
        })
    }

    /*-------------------------------------------------------------------------------
        3) accordion js plugin
    -------------------------------------------------------------------------------*/
    $.fn.accordion = function(option){
        var option = $.extend({
            title  : "",
            content: "",
            speed  : "300"
        }, option);

        this.find("li.active").siblings().find(option.content).hide();
        this.find("li.active "+ option.content).show();

        $(option.title).find("a").on("click",function(e){
            e.preventDefault();
            $current = $(this).closest("li"),
            $cont = $current.find(option.content);

            if($current.hasClass("active")){
                $cont.slideUp(option.speed);
                $current.removeClass("active");
            }else{
                $cont.slideDown(option.speed);
                $current.addClass("active").siblings().removeClass("active").find(option.content).slideUp(option.speed);
            }
            return false;
        })
    }

    /*-------------------------------------------------------------------------------
        4) hint js plugin
    -------------------------------------------------------------------------------*/
    $.fn.hint = function(hintOptions){
        var hintDefaults = {
            position:"bottom"
        },
        hintSettings = $.extend({}, hintDefaults, hintOptions);
        var hintTemplate = "<div class='hint'></span></div>";

        $(this).each(function(){
            $(this).hover(function(){
                $(".hint").remove();
                $("body").append(hintTemplate);
                var hintTitle = $(this).data("title"),
                    toTop = $(this).offset().top,
                    toLeft = $(this).offset().left,
                    hintHeight = $(".hint").css("height"),
                    itemHeight = $(this).css("height");

                if(hintSettings.position == "top"){
                    $(".hint").addClass("arr-down");
                    var topFinal = parseInt(toTop) - parseInt(toolhintHeight) - 10;
                } else {
                    var topFinal = parseInt(toTop) + parseInt(itemHeight) + 10;
                    $(".hint").removeClass("arr-down");
                }

                $(".hint").html(hintTitle);
                $(".hint").fadeIn();
                $(".hint").css({
                    top : topFinal,
                    left : toLeft
                });

            },function(){
                $(".hint").remove();
            });
        });
    }
})(jQuery);
