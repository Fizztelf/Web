/**
 *  테스트
 */


$(document).ready(function(){
	$("h1").css("background-color", "yellow").css("color", "blue");
	$("#test").css("background-color", "green");
	$(".sample").css("background-color", "red");
	alert("시작");
});


$(document).read(function(){
	$("button").click(function(){
		$("p.intro").hide(); // p 요소 중 calss가 intro인 것
		$("p:first").hide(); // p 요소 중 첫 번째 요소
		$("ul li:first").hide(); // ul의 자식 요소 li 중 첫 번째 요소
		$("ul li:first-child").hide(); // ul의 자식 요소 li 중 첫 번째 요소
	});
});
