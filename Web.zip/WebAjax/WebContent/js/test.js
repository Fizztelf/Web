/**
 * 테스트
 */

$(document).ready( function(){
	$("h1").css("background-color", "yellow").css("color", "white");
	$("#test").css("background-color", "green");
	$(".sample").css("background-color", "red");
	alert('시작');
});
