
/* =======================================================
event name : easing
======================================================= */
jQuery.extend( jQuery.easing,
    {
        def: 'easeOutQuad',
        swing: function (x, t, b, c, d) {
            //alert(jQuery.easing.default);
            return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
        },
        easeInQuad: function (x, t, b, c, d) {
            return c*(t/=d)*t + b;
        },
        easeOutQuad: function (x, t, b, c, d) {
            return -c *(t/=d)*(t-2) + b;
        },
        easeInOutQuad: function (x, t, b, c, d) {
            if ((t/=d/2) < 1) return c/2*t*t + b;
            return -c/2 * ((--t)*(t-2) - 1) + b;
        },
        easeInCubic: function (x, t, b, c, d) {
            return c*(t/=d)*t*t + b;
        },
        easeOutCubic: function (x, t, b, c, d) {
            return c*((t=t/d-1)*t*t + 1) + b;
        },
        easeInOutCubic: function (x, t, b, c, d) {
            if ((t/=d/2) < 1) return c/2*t*t*t + b;
            return c/2*((t-=2)*t*t + 2) + b;
        },
        easeInQuart: function (x, t, b, c, d) {
            return c*(t/=d)*t*t*t + b;
        },
        easeOutQuart: function (x, t, b, c, d) {
            return -c * ((t=t/d-1)*t*t*t - 1) + b;
        },
        easeInOutQuart: function (x, t, b, c, d) {
            if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
            return -c/2 * ((t-=2)*t*t*t - 2) + b;
        },
        easeInQuint: function (x, t, b, c, d) {
            return c*(t/=d)*t*t*t*t + b;
        },
        easeOutQuint: function (x, t, b, c, d) {
            return c*((t=t/d-1)*t*t*t*t + 1) + b;
        },
        easeInOutQuint: function (x, t, b, c, d) {
            if ((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
            return c/2*((t-=2)*t*t*t*t + 2) + b;
        },
        easeInSine: function (x, t, b, c, d) {
            return -c * Math.cos(t/d * (Math.PI/2)) + c + b;
        },
        easeOutSine: function (x, t, b, c, d) {
            return c * Math.sin(t/d * (Math.PI/2)) + b;
        },
        easeInOutSine: function (x, t, b, c, d) {
            return -c/2 * (Math.cos(Math.PI*t/d) - 1) + b;
        },
        easeInExpo: function (x, t, b, c, d) {
            return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
        },
        easeOutExpo: function (x, t, b, c, d) {
            return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
        },
        easeInOutExpo: function (x, t, b, c, d) {
            if (t==0) return b;
            if (t==d) return b+c;
            if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
            return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
        },
        easeInCirc: function (x, t, b, c, d) {
            return -c * (Math.sqrt(1 - (t/=d)*t) - 1) + b;
        },
        easeOutCirc: function (x, t, b, c, d) {
            return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
        },
        easeInOutCirc: function (x, t, b, c, d) {
            if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
            return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
        },
        easeInElastic: function (x, t, b, c, d) {
            var s=1.70158;var p=0;var a=c;
            if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
            if (a < Math.abs(c)) { a=c; var s=p/4; }
            else var s = p/(2*Math.PI) * Math.asin (c/a);
            return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
        },
        easeOutElastic: function (x, t, b, c, d) {
            var s=1.70158;var p=0;var a=c;
            if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
            if (a < Math.abs(c)) { a=c; var s=p/4; }
            else var s = p/(2*Math.PI) * Math.asin (c/a);
            return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
        },
        easeInOutElastic: function (x, t, b, c, d) {
            var s=1.70158;var p=0;var a=c;
            if (t==0) return b;  if ((t/=d/2)==2) return b+c;  if (!p) p=d*(.3*1.5);
            if (a < Math.abs(c)) { a=c; var s=p/4; }
            else var s = p/(2*Math.PI) * Math.asin (c/a);
            if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
            return a*Math.pow(2,-10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )*.5 + c + b;
        },
        easeInBack: function (x, t, b, c, d, s) {
            if (s == undefined) s = 1.70158;
            return c*(t/=d)*t*((s+1)*t - s) + b;
        },
        easeOutBack: function (x, t, b, c, d, s) {
            if (s == undefined) s = 1.70158;
            return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
        },
        easeInOutBack: function (x, t, b, c, d, s) {
            if (s == undefined) s = 1.70158;
            if ((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
            return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
        },
        easeInBounce: function (x, t, b, c, d) {
            return c - jQuery.easing.easeOutBounce (x, d-t, 0, c, d) + b;
        },
        easeOutBounce: function (x, t, b, c, d) {
            if ((t/=d) < (1/2.75)) {
                return c*(7.5625*t*t) + b;
            } else if (t < (2/2.75)) {
                return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
            } else if (t < (2.5/2.75)) {
                return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
            } else {
                return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
            }
        },
        easeInOutBounce: function (x, t, b, c, d) {
            if (t < d/2) return jQuery.easing.easeInBounce (x, t*2, 0, c, d) * .5 + b;
            return jQuery.easing.easeOutBounce (x, t*2-d, 0, c, d) * .5 + c*.5 + b;
        }
    }
);


/* =======================================================
미디어쿼리 분기점 :
======================================================= */
var scw = -1;
var _winW = 0;
var scrollbarWidth=function(){var a,b,c;if(c===undefined){a=$('<div style="width:50px;height:50px;overflow:auto"><div/></div>').appendTo('body');b=a.children();c=b.innerWidth()-b.height(99).innerWidth();a.remove();}return c};
//var scrollbarWidth=function(){var a,b,c;if(c===undefined){a=$('<div style="width:50px;height:50px;overflow:auto;border:1px solid red"><div/></div>').appendTo('body');b=a.children();c=b.innerWidth()-b.height(99).innerWidth();}return c};
function sectionMediaQueries(){
        var $html = $('html'),
             $body = $('body');
        if(scw==-1) {
            scw = scrollbarWidth();
        }
        _winW = $(window).width() + scw;
        $html.data('viewportWidth', _winW);

        if( _winW <= 360){
            $html.removeClass('vw-960 vw-1280 vw-wide');
            $html.addClass('mobile vw-360');
        } else if( _winW <= 960){
            $html.removeClass('vw-360 vw-1280 vw-wide');
            $html.addClass('mobile vw-960');
        } else if( _winW <= 1280 ){
            $html.removeClass('mobile vw-360 vw-960 vw-wide');
            $html.addClass('vw-1280');
            $body.removeClass('is-nav-active');
        } else {
            $html.removeClass('mobile vw-360 vw-960 vw-1280');
            $html.addClass('vw-wide');
        }
}
sectionMediaQueries();
$(window).on("resize", function(event) {
    sectionMediaQueries();
});

/* =======================================================
event name : header, footer load
======================================================= */
var load = (function(){

    var query = "?rnd=" + String((new Date()).getTime()).replace(/\D/gi, '');
    $("header").load("/competition/include/header.html"+query, function(){gnbEvent(); });
    $("footer").load("/competition/include/footer.html"+query, function(){footerEvent(); });
})();


/* =======================================================
event name : GNB
======================================================= */
function gnbEvent(){
    var $body =  $("body"),
                $header = $("#header"),
                $gnb = $("#gnb > .gnb-title"),
                $subgnb = $("#subgnb"),
                $gnbbg = $(".gnb-bg"),
                $gnbwmenu = $(".gnb-wmenu"),
                $btnwmenu = $(".btn-wmenu"),
                $subgnbnav = $("#subgnb .depWrap .stickyDep .d1"),
                $subgnbtwoD = $("#subgnb .depWrap .twoD .submenu_list a"),
                $opensidenav = $('.open-sidenav'),
                $lsidenav = $('#l-sidenav');
                $category = $(".category"),
                $content = $(".contents"),
                $util = $header.find(".util"),
                $lang = $header.find(".lang"),
                $langIn = $lang.find(".langLst > a"),
                $dimmed = $('.dimmed'),
                spd = 200,
                gnbtit_h = "50px",
                gnbwmenu_h = "472px",
                gnb_h=0;

            //Base
            if($(window).scrollTop() >= 40){
                    //$header.addClass("is-scroll");
            }

            //초기화
            function gnbInit(){
                $header.removeClass("is-open");
                $gnb.removeClass("on");
                $gnbwmenu.removeClass("on");
                $btnwmenu.removeClass("active");
                $gnbbg.removeClass("whole-bg");
                $gnbbg.animate({"height": "0"}, 0);
            }

             //Bg Height
            function gnbBgOpen(e,idx){
                if (idx==5){
                        gnb_h = gnbwmenu_h;
                }else{
                        gnb_h = gnbtit_h;
                }
                if(e == "open"){
                       $gnbbg.animate({"height": gnb_h}, spd);
                }else{
                        $gnbbg.animate({"height": "0"}, spd);
                }
            }

            //Mouse Control
            $gnb.on("mouseenter", function(){ // mouseenter
                if(!$gnbwmenu.hasClass("on")){
                    $(this).addClass("on").siblings().removeClass("on");
                    if($(this).find(".submenu").length <= 0){
                            $header.removeClass("is-open");
                            gnbBgOpen("close", $(this).index());
                    }else{
                            $header.addClass("is-open");
                            gnbBgOpen("open",$(this).index());
                    }
                }
            });
            $header.on("mouseleave", function(){ // mouseleave
                if(!$gnbwmenu.hasClass("on")){
                    $gnb.removeClass("on");
                    $header.stop().removeClass("is-open");
                    gnbBgOpen("close");
                }
            });

    //Keyboard Control
    $gnb.find("> a").on("focusin", function(){
                    if(!$gnbwmenu.hasClass("on")){
                        $(this).closest("li").addClass("on").siblings().removeClass("on");
                        if($(this).closest("li").find(".submenu").length <= 0){
                            $header.removeClass("is-open");
                            gnbBgOpen("close");
                        }else{
                            $header.addClass("is-open");
                            gnbBgOpen("open");
                        }
                    }
    });
    $header.find(".logo a").on("focus", function(){
                    if($("#gnb > li:first").hasClass("on")){
                        $gnb.removeClass("on");
                        $header.removeClass("is-scroll");
                        gnbBgOpen("close");
                    }
    });

            //gnb
    $gnb.find('a').on('click', function(){
                    $gnb.removeClass("on");
    });

            //전체 메뉴 열기
            $gnbwmenu.find('.btn-wmenu').on('click', function(){
                $gnb.removeClass("on");
                $gnbwmenu.toggleClass("on");
                $btnwmenu.toggleClass("active");
                $gnbbg.toggleClass("whole-bg");
                if($btnwmenu.hasClass("active") == false){
                    gnbBgOpen("close",5);
                }else{
                    gnbBgOpen("open",5);
                }
                 return false;
            });

            // Language Select
            $langIn.on("click", function(){
                $lang.toggleClass("on");
                return false;
            })
            // Language focus
            $lang.find(".langLst li:last a").blur(function(){
                $util.removeClass("on");
            })

            // Scroll
            $(window).scroll(function(){
                var scroll = $(this).scrollTop();


                if(scroll >= 40){
                    $header.addClass("is-scroll");
                    gnbInit();

                    /*
                    $gnb.removeClass("on");

                    if($('.btn-wmenu').hasClass("active")){
                        $('.btn-wmenu').click();
                    }

                    $gnbbg.css("height","0");

                    */
                }else{
                    $header.removeClass("is-scroll");
                }
                //if(scroll >= 40) $header.addClass("fixed").css({"height": 70});
                //else $header.removeClass("fixed").css({"height": 110});
            })

            // subGnb
            $subgnbnav.click(function(){
                if($(this).hasClass("on") == false){
                    $("#subgnb .depWrap .stickyDep .d1").removeClass("on");
                    $("#subgnb .depWrap .submenu_list").slideUp(200);
                    $(this).addClass("on");
                    $(this).next("div").slideDown(200);
                }else{
                    $(this).removeClass("on");
                    $(this).next("div").slideUp(200);
                }
            });
            $subgnb.mouseleave(function(){
               $("#subgnb .depWrap .stickyDep .d1").stop().removeClass("on");
               $("#subgnb .depWrap .submenu_list").stop().slideUp(200);
            });


            //모바일용
            if($(window).scrollTop() > $(window).height() / 8){
                $('body').addClass('scroll');
                $('body').removeClass('scroll');
            }
            //Sidenav 활성
            var activeSidenav =  function(){$('body').addClass('is-nav-active'); $lsidenav.stop().animate({ "right": "0" }, 300, "swing" ); $opensidenav.addClass('active'); $dimmed.show()};
            //Sidenav 비활성
            var inactiveSidenav = function(){
                $('body').removeClass('is-nav-active');
                $lsidenav.stop().animate({ "right": "-100%" }, spd, "swing" );
                $opensidenav.removeClass('active');
                $dimmed.hide();
            };
            //sideNav
            $opensidenav.on('click', function(){
                var $this = $(this);

                if($(this).hasClass('active')){
                    inactiveSidenav();
                } else {
                    activeSidenav();
                }
            });

            //gnb 초기값
            $('.dropdown > dt').eq(0).addClass('on');
            $('.dropdown > dd').eq(0).show();

            $('.dropdown > dt').on('click', function(){
                var $this = $(this),
                    $dd = $(this).next('dd'),
                    spd = 200;

                if($this.hasClass('on')){
                    $this.removeClass('on');
                    $dd.slideUp(spd);
                } else {
                    $('.dropdown > dt').removeClass('on');
                    $('.dropdown > dd').slideUp(spd);
                    $this.addClass('on');
                    $dd.slideDown(spd);
                }
            });
            $('.dropdown > dd > ul > li > a').on('click', function(){
                $('.open-sidenav').click();

            });
            var checkSidenav = function(){
                if( _winW >= 960 ){
                        inactiveSidenav();
                }else{
                    if($('.btn-wmenu').hasClass("active")){
                        gnbInit();
                    }
                }
            };
            $(window).on("resize", function(event) {
                checkSidenav();
            });

         /* btn-pview gnb 프로그램버튼 */
         $('.program .btn-pview').on('click', function(){
            var _this = $(this),
                $programView = _this.parent('.program');

                if(!$programView.hasClass("on")){
                    $programView.addClass("on");
                }else{
                     $programView.removeClass("on");
                }
         });

          /* stickyNav 닫기 */
         $subgnbtwoD.on('click', function(){
            var _this = $(this);
            $("#subgnb .depWrap .submenu_list").slideUp(200);
         });
}


/* =======================================================
event name : footer
======================================================= */
function footerEvent(){
        var $top = $(".topbtn"),
            _wheight = $(window).height(),
            _height = $("#wrap").height(),
            _if = false;

        $top.hide();

        $(window).scroll(function(){
            var _scroll = $(window).scrollTop();

            if(_scroll >= _wheight) $top.show();
            else $top.hide();
        });

        // go top button click
        $top.on("click", function(){
            $("html, body").animate({"scrollTop": 0 }, 400, "swing");
            return false;
        });

        //모바일용 본선 신청하기
        var _isProgramOpen = false;
        $('.program-btn').on('click', function(e) {
            e.preventDefault();
            if(_isProgramOpen){
                $(".programWrap").removeClass('active');
                _isProgramOpen = false;
            }else{
                $(".programWrap").addClass('active');
                _isProgramOpen = true;
            }
        });

        $("body").click(function(e){ // 관련사이트 열린상태에서 다른 곳 클릭시
            if(_if == true){

            }
        });
}


/* =======================================================
event name : Select Box //2018-03-22 아이파
======================================================= */
var selectBox = (function(){
        var $select = $(".select"),
            $select_select = $(".select").find("select"),
            $sphone = $(".nonplace.phone"),
            _if_sphone = $sphone.size(),
            _if = $select.size(),
            _select_click = false;

        if(_if <= 0) return false;

        $select.each(function(){
            if($(this).find("option:first").is(":selected")){
                $(this).addClass("placeholder");
                //연락처 inputbox : 국외선택 시, 인풋박스의 예시입력문구 미노출용
                if(_if_sphone > 0){
                    $sphone.find(".inputHpnum").removeClass("foreign");
                }
            }
        });
        $select_select.change(function(){
            var _select_id = $(this).attr("id");

            if($(this).find("option:first").is(":selected")){
                $(this).addClass("placeholder");
                //연락처 inputbox : 국외선택 시, 인풋박스의 예시입력문구 미노출용
                if(_if_sphone > 0 && _select_id== "ntNum"){
                    $sphone.find(".inputHpnum").removeClass("foreign");
                }
            }else{
                $(this).removeClass("placeholder");
                //연락처 inputbox : 국외선택 시, 인풋박스의 예시입력문구 미노출용
                 if(_if_sphone > 0 && _select_id== "ntNum"){
                    $sphone.find(".inputHpnum").addClass("foreign");
                }
            }
            $(this).parent().addClass('active');
             _select_click = true;

        });
        $select.on("click", function(){
            if(_select_click){
                  $(this).removeClass('active');
                  _select_click = false;
            }else{
                  $(this).addClass('active');
                  _select_click = true;
            }
        });
})();

/* =======================================================
event name : tab
======================================================= */
function tabJs(parent, menu, cont){ // 탭과 컨텐츠의 최상위 부모, 탭메뉴, 컨텐츠
        var $tab = $(parent),
        $menu = $tab.find(menu),
        $cont = $tab.find(cont),
        _i = 0;

        $cont.eq(_i).show();
        $menu.find("a").on("click", function(){
            _i = $(this).closest("li").index();
            $(this).closest("li").addClass("current").append("<span class='hidden'>현재 탭</span>").siblings().removeClass("current").find(".hidden").remove();
            $cont.eq(_i).addClass("on").show().siblings(cont).removeClass("on").hide();
            return false;
        });
}


/* =======================================================
event name : Accodion slide
======================================================= */
function accodion(parent, question, answer){ // 아코디언 메뉴명, 질문, 답변
    var $root = $(parent),
        $question = $root.find(question),
        $answer = $root.find(answer),
        $current = "",
        spd = 300;

        $root.find("li.on").siblings().find(answer).hide();
        $root.find("li.on "+ answer).show();


        $question.find("a").on("click", function(){
            $current = $(this).closest("li"),
            $answer = $current.find(answer);

            if($current.hasClass("on")){
                $answer.slideUp(spd);
                $current.removeClass("on");
            }else{
                $answer.slideDown(spd);
                $current.addClass("on").siblings().removeClass("on").find(answer).slideUp(spd);
            }
            return false;
        })
}


/* =======================================================
event name : layerPop
======================================================= */
function layerPop(fileName, layerSize, idName, idValue){
    var _html = "",
         $wrap = $("#wrap");

            _html = "/competition/layer/" + fileName + ".html";

    var _when = $wrap.after(function(){
        if(layerSize == "small"){
            return "<div id='layer' class='small'><div class='layerInner'></div></div>"
        }else if(layerSize == "medium"){
            return "<div id='layer' class='medium'><div class='layerInner'></div></div>"
        }else{
            return "<div id='layer' class='large'><div class='layerInner'></div></div>"
        }
    });

    $.when(_when).done(function(){
        var $layer = $("#layer");
        $layer.find(".layerInner").load(_html, function(){
            var _title = $(this).find("h1.tit").text();
            $(this).append('<p class="closeBtn closeJs"><button type="button"><span>'+ _title +' 레이어 닫기</span></button></p>');

            // 레이어닫기 버튼 추가
            if(fileName != "team_register_confirm" && fileName != "team_out_confirm" && fileName != "not_registered"){
                alert();
                $(this).append('<p class="closeBtn closeJs"><button type="button"><span>'+ _title +' 레이어 닫기</span></button></p>');
            }
            $layer.fadeIn(300).find("a, button, textarea, input, select").focus();

            var layH = $(this).outerHeight()/2;

            var $close = $(this).find(".closeJs");
            $close.on("click", function(){
                $layer.remove();
            })


        })
    })
}

/* =======================================================
event name : printIt 인쇄하기
======================================================= */
function printIt(elem){
    printPopup($(elem).html());
}
function printPopup(data)
{
    var mywindow = window.open('', 'my div', 'height=800,width=1024');
    mywindow.document.write('<html><head><title>my div</title>');
    mywindow.document.write('</head><body >');
    mywindow.document.write(data);
    mywindow.document.write('</body></html>');
    mywindow.document.close(); // IE >= 10에 필요
    mywindow.focus(); // necessary for IE >= 10
    mywindow.print();
    mywindow.close();
    return true;
}

/* =======================================================
event name : joinInfo placeholder
======================================================= */
var $joinInfo = $(".joinInfo li.placeharea"),
    $joinInfo0, $joinInfo1, $joinInfo2, $joinInfo3, $joinInfo4, $joinInfo5, $joinInfo6;
function JoinInit(){
      $joinInfo0 = $(".joinInfo li.placeharea").eq(0).find("input").attr("placeholder"),
      $joinInfo1 = $(".joinInfo li.placeharea").eq(1).find("input").attr("placeholder"),
      $joinInfo2 = $(".joinInfo li.placeharea").eq(2).find("input").attr("placeholder"),
      $joinInfo3 = $(".joinInfo li.placeharea").eq(3).find("input").attr("placeholder"),
      $joinInfo4 = $(".joinInfo li.placeharea").eq(4).find("input").attr("placeholder"),
      $joinInfo5 = $(".joinInfo li.placeharea").eq(5).find("input").attr("placeholder"),
      $joinInfo6 = $(".joinInfo li.placeharea").eq(6).find("input").attr("placeholder"),
      $joinInfo7 = $(".joinInfo li.placeharea").eq(7).find("input").attr("placeholder");
}
function JoinPc(){ //PC 회원가입 정보입력 placeholder
    $(".joinInfo li.placeharea").eq(0).find("input").attr("placeholder", $joinInfo0),
    $(".joinInfo li.placeharea").eq(1).find("input").attr("placeholder", $joinInfo1),
    $(".joinInfo li.placeharea").eq(2).find("input").attr("placeholder", $joinInfo2),
    $(".joinInfo li.placeharea").eq(3).find("input").attr("placeholder", $joinInfo3),
    $(".joinInfo li.placeharea").eq(4).find("input").attr("placeholder", $joinInfo4),
    $(".joinInfo li.placeharea").eq(5).find("input").attr("placeholder", $joinInfo5),
    $(".joinInfo li.placeharea").eq(6).find("input").attr("placeholder", $joinInfo6),
    $(".joinInfo li.placeharea").eq(7).find("input").attr("placeholder", $joinInfo7);
}
function JoinMobile(){ //모바일 회원가입 정보입력 placeholder
          $joinInfo.each(function(index){
                var $label = $(this).find("label").text(),
                      $input =  $(this).find("input");
                $input.attr("placeholder",$label);
          });
}
var loadJoin = (function(){
        //placeholder 초기값 세팅
       JoinInit();
       if ($('.utility .joinZone') && $('html').hasClass("mobile") ){
           JoinMobile();
        }else{
            JoinPc();
        }
})();
$(window).on("resize", function(event) {
       if ($('.utility .joinZone') && $('html').hasClass("mobile") ){
           JoinMobile();
        }else{
            JoinPc();
        }
});

/* =======================================================
event name : initCommunityList 커뮤니티 리스트 위치값
======================================================= */
function initCommunityList($target, items, callback) {
        var $items = $target.find(items);
        $target.attr("style","");
        $items.attr("style","");
        //pc일때 실행
        if(!$("html").hasClass("mobile")){
            $target.find(".communityBox:nth-child(odd)").css("left","0");
            $target.find(".communityBox:nth-child(even)").css("right","0");
            //$target.find(".communityBox:nth-child(odd)").addClass("left");
            //$target.find(".communityBox:nth-child(even)").addClass("right");

            var _initLeftTop = 0, _initRightTop=0;
            $target.find(".communityBox:nth-child(odd)").each(function(idx, el) {
                var $this = $(this);
                $this.css("top",_initLeftTop);
                _initLeftTop = _initLeftTop + ($this.height()+10);
            });
            $target.find(".communityBox:nth-child(even)").each(function(idx, el) {
                var $this = $(this);
                $this.css("top",_initRightTop);
                _initRightTop = _initRightTop + ($this.height()+10);
            });

            var targetMax =  Math.max(_initLeftTop, _initRightTop);
            $target.css("height",targetMax);
        }
}


$(document).ready(function(){
    /* =======================================================
    event name : checkBox //2018-03-22 아이파
    ======================================================= */
    $('input.check').on('click', function(){
        var $this = $(this),
            mycheck = $this.is(":checked"),
            policy = $('input:checkbox[name=policy]').is(":checked"),
            privacy1 = $('input:checkbox[name=privacy1]').is(":checked"),
            privacy2 = $('input:checkbox[name=privacy2]').is(":checked"),
            allagree = $('input:checkbox[name=allagree]').is(":checked");

            if(mycheck){
                $this.siblings(".checkBox").addClass("on");
                if( $this.attr('name') == 'allagree'){
                    document.getElementById("policy").checked = true;
                    document.getElementById("privacy1").checked = true;
                    document.getElementById("privacy2").checked = true;
                    $("#policy").siblings("label").addClass("on");
                    $("#privacy1").siblings("label").addClass("on");
                    $("#privacy2").siblings("label").addClass("on");
                }else{
                    if ($("#allagree").size()>0) {
                        if( policy && privacy1 && privacy2 ) {
                            document.getElementById("allagree").checked = true;
                            $("#allagree").siblings("label").addClass("on");
                        }
                    }
                }
            }else{
                $this.siblings(".checkBox").removeClass("on");
                if( $this.attr('name') == 'allagree'){
                    document.getElementById("policy").checked = false;
                    document.getElementById("privacy1").checked = false;
                    document.getElementById("privacy2").checked = false;
                    $("#policy").siblings("label").removeClass("on");
                    $("#privacy1").siblings("label").removeClass("on");
                    $("#privacy2").siblings("label").removeClass("on");
                }else{
                    if ($("#allagree").size()>0) {
                         document.getElementById("allagree").checked = false;
                         $("#allagree").siblings("label").removeClass("on");
                    }
                }
            }
    });
    /* =======================================================
    event name : radioBox  //2018-03-22 아이파
    ======================================================= */
    $('input.radio').on('click', function(){
            var $this = $(this);
            $('.radioBox').removeClass('on');
            $this.siblings(".radioBox").addClass("on");
    });

    /* =======================================================
    event name : radioType Button
    ======================================================= */
    $('.radioType button').on('click', function(){
            $('.radioType button').removeClass('on');
            $(this).addClass('on');
    });

    /* =======================================================
    event name : Accodion Box 회원가입,커뮤니티   //2018-03-12 아이파 - item  추가
    ======================================================= */
    $('.accoBox .tit').on('click', function(){
                var $this = $(this),
                    $item = $(this).parent(),
                    $dd = $(this).parent().parent('.item').next('.desc'),
                    _spd = 200;
                if($this.hasClass('on')){
                    $this.removeClass('on');
                    $item.removeClass('on');
                    var effect = function() {
                        return $dd.slideUp(_spd);
                    };
                    effect();
                    if ($('.communityBox').size()>0){
                         $item.find(".btn_cwrite ").removeClass('on');
                         $item .find("span").html($item.find(".btn_cwrite span").attr("data-off-txt"));
                    }
                } else {
                    $this.addClass('on');
                    $item.addClass('on');
                    var effect = function() {
                        return $dd.slideDown(_spd);
                    };
                    effect();
                     if ($('.communityBox').size()>0){
                         $item.find(".btn_cwrite ").addClass('on');
                        $item .find("span").html($item.find(".btn_cwrite span").attr("data-on-txt"));
                    }
                }
                //커뮤니티인 경우 위치값 재조정
                if ($('.communityBox').size()>0){
                     $.when( effect() ).done(function() {
                       $("html, body").animate({"scrollTop": $this.offset().top-100 }, 400, "swing");
                       initCommunityList($(".communityList"), $(".communityBox"));
                      });
                }
    });

    /* =======================================================
    event name : dataCard 자료실 레이어
    ======================================================= */
    if ($('.dataCard').size()>0){
                //레이어 열기
                $(".dataCard").on('click', function(){
                    $("body").addClass("is-data-active");//필수
                    $("#layer").show();
                });
                //레이어 닫기
                $(".closedata").on('click', function(){
                    $("body").removeClass("is-data-active"); //필수
                    $("#layer").hide();
                });
    }

    /* =======================================================
    event name : 커뮤니티 스크롤러, pc용
    ======================================================= */
    if ($('.etcBox.community').size()>0){
        $('.scrollbar-inner').scrollbar();
        $('.textarea-scrollbar').scrollbar();
    }

    /* =======================================================
    event name : dFile 파일첨부
    ======================================================= */
     /* input file */
     $('.dFile').on('click', function(){
        var _this = $(this),
            valTxt = _this.find('.valTxt'),
            valProg = _this.find('.progress-wrap'),
            _input = _this.find('input'),
            _delFile = _this.find('.delFile'),
            _fileVolume = _this.find('.fileVolume'),
            val = _input.val();

        valTxt.text(val);

        _input.bind('change' ,function(){
            val = $(this).val();
            valTxt.text(val);
            _delFile.show();
            _fileVolume.show();
            valTxt.addClass("off");
            valProg.addClass("off")
        });
        _delFile.on('click', function(){
            _input.val("");
            _delFile.hide();
            _fileVolume.hide();
            valTxt.removeClass("off");
            valProg.removeClass("off")
        })
     });

});



