/* =======================================================
event name : header, footer load
======================================================= */
var load = (function(){
    $("header").load("../web/include/header.html", function(){gnbEvent();loginEvent()});
    $("#sidenav").load("../web/include/sidemenu.html", function(){sidemenuEvent()});
    $("footer").load("../web/include/footer.html");
})();

/***************************************************
 * GNB
 ***************************************************/
 function gnbEvent(){
    /* alim-layer */
	if($(".alim-layer").is(':visible') == false ) {
		$(".wrapper").removeClass("has-alim")
	} else {
		$(".wrapper").addClass("has-alim")
	}
	 
    $(".alim-layer .ico-close").on("click",function(){
        $(".alim-layer").slideUp();
        $(".wrapper").removeClass("has-alim")
    });
}

/***************************************************
 * LoginEvent
 ***************************************************/
function loginEvent(){
    $('input[name="authType"]').change(function() {
        $(".logintypebox").addClass('d-none');
        $('#' + $(this).val()).removeClass('d-none');
    });

    $('.loginbox input').focus(function() {
        $(this).prev('label').hide();
    });
    $('.loginbox input').blur(function() {
        if($(this).val()=="") {
            $(this).prev('label').show();
        } else {
            $(this).prev('label').hide();
        }
    });
}

/***************************************************
 * zoomin, zoomout
 ***************************************************/
var nowZoom = 100;
var zoomControl  = {
    zoomOut : function(){
        nowZoom = nowZoom - 5;
        if(nowZoom <= 90) nowZoom = 90;
        zoomControl.zooms();
        $('.zoom-text > a').text(nowZoom+'%')
    },
    zoomIn : function(){
        nowZoom = nowZoom + 5;
        if(nowZoom >= 120) nowZoom = 120; 
        zoomControl.zooms();
        $('.zoom-text > a').text(nowZoom+'%')
    },
    zoomReset : function(){     
        nowZoom = 100;
        zoomControl.zooms();
        $('.zoom-text > a').text(nowZoom+'%')
    },
    zooms : function(){
        document.body.style.zoom = nowZoom + "%";
        if(nowZoom == 90) {
            alert("더 이상 축소할 수 없습니다.");  
        }
        if(nowZoom == 120) {
            alert("더 이상 확대할 수 없습니다.");
        }
    }
}


/***************************************************
 * search
 ***************************************************/
function detailSrcToggle(){
    $(".detail-srcarea").slideToggle();
    $(".ico-toggle").toggleClass('up')
}

/***************************************************
 * 첨부파일 ellipsis
 ***************************************************/
function dotText(){	
	$(".apply-file .brief-header .name").each(function(){
	    var length = 25; //표시할 글자수 정하기
	    $(this).each(function(){
	        if( $(this).text().length >= length ){	
	            $(this).text( $(this).text().substr(0,length)+'...') 	
	        }
	    });
	});
}

/***************************************************
 * owl slide
 ***************************************************/
function applyslide(){
    /* owlCarousel */
    var owl = $('.applyslide');
    owl.each(function(){
        owl.owlCarousel({
            loop:false,
            nav:false,
            margin:0,
            responsive:{
                0:{items:1},
                768:{items:2},
                1000:{items:3}
            }
        });
    });
    
    $(".ico-brief-close").on("click",function(){
        var itemIdx = $(this).closest('.owl-stage').children().index($(this).closest('.owl-item'));
        $(this).closest(".owl-item").trigger('remove.owl.carousel',itemIdx);
        $('.applyslide .owl-carousel').trigger('refresh.owl.carousel');
    });    
    
    owl.on('changed.owl.carousel', function(event) { 
    	dotText();
    	$(this.children).trigger("resize");
    });
}
/***************************************************
 * document layer close
 ***************************************************/
function docLayerClose(){
    $(".document-layer .ico-layer-close").on("click",function(){
        $(this).parent(".document-layer").slideUp();
    });
}

/***************************************************
 * window popup right
 ***************************************************/
function windowPop(href, w, h) {
    xPos = (document.body.offsetWidth) - w;
    xPos += window.screenLeft; // 듀얼 모니터일 때
    var yPos = 0;
    window.open(href, "pop_name", "width="+w+", height="+h+", left="+xPos+", top="+yPos+", menubar=no, status=no, titlebar=no, resizable=no");
}

/* =======================================================
* scrollable table
======================================================= */
function scrolltbl(){
    var $scrollTable = $('.table-header-fixed');
    var colWidthArr = $scrollTable.find('thead tr:first').children('th').map(function() {
            return $(this).css('width');
        }).get();

    $scrollTable.find('tbody tr:first').children('td').each(function(idx) {
        $(this).css('width',colWidthArr[idx]);
        if($(this).is(":last-child")){
            $(this).css('width','auto')
        }
    });    
}

/***************************************************
 * sidemenu
 ***************************************************/
function sidemenuEvent(){
    $(".sidemenu>ul>li:has(ul)").addClass("has-sub");
    $(".sidemenu>ul>li:has(.active)").find("ul").slideDown();
    $(".sidemenu>ul>li>a").on("click",function(e){
        e.preventDefault();
        if($(this).parent('li').hasClass('active')){

        } else {
            $(".sidemenu>ul>li").removeClass('active').find("ul").slideUp();
            $(this).closest("li").addClass('active').find("ul").slideDown();
        }
    })
}

/* =======================================================
* window popup
======================================================= */
// use >> <a href=# onclick=pop('./x.html','','767','1000','y');>[열기]</a>
var pop = function(html_uri, pop_up_name, option_width, option_height, option_selection){
    var popupObject = null;
    var option  = "width="   + option_width                      +","
    option += "height="      + option_height                     +","
    option += "left="        + (screen.width - option_width)/2   +","
    option += "top="         + (screen.height - option_height)/2 +",";
    
    if(option_selection == null){
        option_selection = "y";
    }
    
    if(option_selection == 'yes' || option_selection == 'y'){
        option += 'fullscreen=no, location=no, scrollbars=yes, menubar=no, toolbar=no, titlebar=no, directories=no, resizable=yes';
    } else if(option_selection == 'no' || option_selection == 'n'){
        option += 'fullscreen=no, location=no, scrollbars=no, menubar=no, toolbar=no, titlebar=no, directories=no, resizable=no';
    } else {
        option += option_selection;
    }
    popupObject = window.open(html_uri,pop_up_name, option);
}

$(document).ready(function(){

    /* browser check */
    var browser_name = '';
    isIE = /*@cc_on!@*/false || !!document.documentMode;
    isEdge = !isIE && !!window.StyleMedia;
    if(navigator.userAgent.indexOf("Chrome") != -1 && !isEdge){ 
        browser_name = 'chrome';
    } 
    else if(navigator.userAgent.indexOf("Safari") != -1 && !isEdge){
        browser_name = 'safari';
    } 
    else if(navigator.userAgent.indexOf("Firefox") != -1 ) {
        browser_name = 'firefox';
    } 
    else if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) {
        browser_name = 'ie';
    } 
    else if(isEdge) {
        browser_name = 'edge';
    } else {
        browser_name = 'other-browser';
    } 
    $('html').addClass(browser_name);

    gnbEvent();
    sidemenuEvent();
    applyslide();

    $("a[href='#']").on("click", function(e) {
        e.preventDefault();      
    }) 

    $(".btn-brief-add, .ico-person, .brief-header, .ico-monitor.btn-secondary").attr("title","레이어 팝업 열림");
    $(".apply-file .brief-header").attr("title","파일 다운로드");
    $("#popAllCar").attr("title","새창 열림");

    $(".category .dropdown-item").click(function(){
        $(this).parents(".dropdown").find('.dropdown-toggle').html($(this).text() + ' <span class="caret"></span>');
        $(this).parents(".dropdown").find('.dropdown-toggle').val($(this).data('value'));
    });

    /* browser title*/
    if($(document).find('.page-title').length !== 0){
        var title = $(".page-title>strong").text();
        document.title = title + " | 남북교류협력시스템";
    }

    if($(document).find('.popup-title').length !== 0){
        var title = $(".popup-title").text();
        document.title = title + " | 남북교류협력시스템";
    }

    /* tooltip */
    $('[data-toggle="tooltip"]').tooltip();

    $(".applyarea .ico-toggle").on("click", function(){
        $(this).parent().next('.collapse').collapse('toggle');
        $(this).toggleClass('up');
    });

    $(window).on('load resize', function() {
        scrolltbl()
    }).resize(); 


    /* text ellipsis */
    $(".apply-file .brief-header .name").each(function(){
        var length = 30;
        $(this).each(function(){
            if( $(this).text().length >= length ){
                $(this).text( $(this).text().substr(0,length)+'...') 
                //지정할 글자수 이후 표시할 텍스트
            }
        });
    });

    /* popup close */
    $(".popup-wrap .ico-close.ico-btn").click(function(){
        self.close();
    });
    
    /* 정보수정, 저장, 취소 */
    $(".applyarea .card-header .ico-edit").on("click",function(){
    	setIptWidth(this,false);
    	$(this).closest(".card").removeClass('read').addClass('update');
    })
    $(".applyarea .card-header .ico-cancel, .applyarea .card-header .ico-save2").on("click",function(){
    	setIptWidth(this,true);
    	$(this).closest(".card").removeClass('update').addClass('read');
    })
    
    //초기 실행
    function initApplyarea(){
    	$(".applyarea.card").each(function(){
    		if($(this).hasClass("read")){
    			setIptWidth(this,true);
    		}
    	});
    }
    initApplyarea();
    
    function setIptWidth(target,isView){
    	var parent = getParentCard(target);
    	if(parent == null){return;}
        var ipts = parent.querySelectorAll("input, select");
        for(var i = 0, len = ipts.length; i < len ;i++){
        	var item = ipts[i];
        	var strVal = item.value;
        	if(isView){
        		var byte = strByteLength(strVal);
        		var width = 0;
        		for(z = 0, zLen = strVal.length; z < zLen ; z++){
        			var str = strVal[z];
        			if(str != " "){
        				width += strByteLength(str) == 1 ? 10 : 15;
        			}else{
        				width += 2;
        			}
        		}
        		$(item).css({"width":width + "px","padding":0});
        	}else{
        		item.removeAttribute("style");
        	}
        }
    }
    
    function getParentCard(target){
    	var parent = target;
    	while(!$(parent).hasClass("applyarea card")){
    		parent = parent.parentElement;
    		if(parent == null){break;}
    	}
    	return parent;
    }
    
    function strByteLength(s,b,i,c){
	  for(b=i=0;c=s.charCodeAt(i++);b+=c>>11?3:c>>7?2:1);
	  return b
	}
    
    /* agreearea scroll */
    $(".scroll").mCustomScrollbar();

    /* form validation Check*/
    'use strict';
    window.addEventListener('load', function() {
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
    }, false);

    
});



