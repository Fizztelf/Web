package kr.or.ddit.base.dao;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.common.SqlMapClientFactory;

public class BaseDao2_1023 {
	
	private SqlMapClient smc;
	
	
	
	protected SqlMapClient getSqlMapClient() {
		
		if(smc == null) {
			smc = SqlMapClientFactory.getInstance();
		}
		return smc;
	}
	
	
}
