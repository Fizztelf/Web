package kr.or.ddit.base.vo;

public class BaseVO {
	
	public static final String ACTION_C = "C";
	public static final String ACTION_R = "R";
	public static final String ACTION_U = "U";
	public static final String ACTION_D = "D";
	public static final String VIEW_TYPE_EDIT = "VIEW_TYPE_EDIT";
	
}
