package kr.or.ddit.member.dao;

import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.base.dao.BaseDao;
import kr.or.ddit.member.vo.MemberVO;

public class MemberDao extends BaseDao {
	
	private SqlMapClient smc;
	
	public MemberDao() {
		smc = super.getSqlMapClient();
	}
	
	public MemberVO retrieveMember(String memberId) throws Exception {
		MemberVO resultVo = (MemberVO) smc.queryForObject("member.retrieveMember", memberId);
		return resultVo;
	}
	
	@SuppressWarnings("unchecked")
	public List<MemberVO> retrieveMemberList(MemberVO memberVo) throws Exception {
		List<MemberVO> list = new ArrayList<MemberVO>();
		list = smc.queryForList("member.retrieveMemberList", memberVo);
		return list;
	}
	public int retrieveMemberListCount(MemberVO memberVo) throws Exception {
		return (int) smc.queryForObject("member.retrieveMemberListCount", memberVo);
	}
	
}
