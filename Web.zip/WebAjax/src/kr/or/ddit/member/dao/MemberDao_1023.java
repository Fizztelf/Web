package kr.or.ddit.member.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.base.dao.BaseDao2_1023;
import kr.or.ddit.member.vo.MemberVO;

public class MemberDao_1023 extends BaseDao2_1023 {

   private SqlMapClient smc;

   public MemberDao_1023() {
		smc = super.getSqlMapClient();
   }


   public int createMember(MemberVO memberVo2) throws Exception {
	      int cnt = 0;
	      try {
	         Object obj = smc.insert("member.insertMember",memberVo2);

	         if(obj==null) {
	            cnt=1;
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	      return cnt;
	   }

	   public int updateMember(MemberVO memberVo) throws Exception {
	      int cnt = 0;
	      try {
	      
	         cnt = smc.update("member.updateMember",memberVo);
	      
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }

	      return cnt;
	   }

	   public int deleteMember(MemberVO memberVo) throws Exception {
	      int cnt = 0;
	      try {
	      cnt = smc.delete("member.deleteMember",memberVo.getMemid());

	      } catch (SQLException e) {
	         e.printStackTrace();
	      }

	      return cnt;
	   }

	   public MemberVO retrieve(MemberVO memberVo) throws Exception {
	     
	      
	      MemberVO vo =  (MemberVO) smc.queryForObject("member.retriveList",memberVo);
	      
	         return vo;
	   }

	   public List<MemberVO> retrieveList(MemberVO memberVo) throws Exception {
	      List<MemberVO> memList = new ArrayList<MemberVO>();
	      try {
	      
	         memList = smc.queryForList("member.getMemberAll", memberVo);
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }

	      return memList;
	   }
	}