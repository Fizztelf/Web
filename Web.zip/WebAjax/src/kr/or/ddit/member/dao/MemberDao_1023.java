package kr.or.ddit.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.base.dao.BaseDao_1023;
import kr.or.ddit.member.vo.MemberVO;

public class MemberDao_1023 extends BaseDao_1023 {
	
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public MemberDao_1023() {
		//super : BaseDao의 getConnection 이라는 뜻
		con = super.getConnection();
	}
	
	public void closeConnection() {
		super.closeConnection();
	}
	
	public MemberVO retrieve(MemberVO memberVo) throws Exception {
		MemberVO vo = null;
		
		String sql = "SELECT MEM_ID id" + 
					"	, MEM_PASS" + 
					"	, MEM_NAME name" + 
					"	, MEM_REGNO1" + 
					"	, MEM_REGNO2" + 
					"	, TO_CHAR(MEM_BIR, 'yyyyMMDD') birthday" +//오라클 
					"	, MEM_ZIP" + 
					"	, ADD1 addr" + 
					"	, ADD2" + 
					"	, HP tel" + 
					"	, MAIL" + 
					"	, JOB" + 
					"FROM MEMBER";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, memberVo.getMemId());
		
		rs = stmt.executeQuery();
		while(rs.next()) {
			vo = new MemberVO();
			vo.setMemId(rs.getString("id"));
			vo.setMemName(rs.getString("name"));
			vo.setMemBir(rs.getString("birthday"));
			vo.setMemAdd1(rs.getString("addr1"));
			vo.setMemAdd2(rs.getString("addr2"));
			vo.setMemHp(rs.getString("tel"));
			vo.setMemJob(rs.getString("job"));
		}
		rs.close();
		stmt.close();
		
		return vo;
	}
	
	public List<MemberVO> retrieveList(MemberVO memberVo) throws Exception {
		List<MemberVO> list = new ArrayList<MemberVO>();
		
		String sql = "SELECT MEM_ID id" + 
				"	, MEM_PASS password" + 
				"	, MEM_NAME name" + 
				"	, MEM_REGNO1" + 
				"	, MEM_REGNO2" + 
				"	, MEM_BIR birthday" + 
				"	, MEM_ZIP zip" + 
				"	, ADD1 addr1" + 
				"	, ADD2 addr2" + 
				"	, HP tel" + 
				"	, MAIL mail" + 
				"	, JOB job" + 
				"  FROM MEMBER";
		stmt = con.prepareStatement(sql);
//		stmt.setString(1, memberVo.getId());
//		stmt.setString(2, memberVo.getName());
		
		rs = stmt.executeQuery();
		while(rs.next()) {
			MemberVO vo = new MemberVO();
			vo.setMemId(rs.getString("id"));
			vo.setMemName(rs.getString("name"));
			vo.setMemBir(rs.getString("birthday"));
			vo.setMemAdd1(rs.getString("addr1"));
			vo.setMemAdd2(rs.getString("addr2"));
			vo.setMemHp(rs.getString("tel"));
			vo.setMemJob(rs.getString("job"));
			list.add(vo);
		}
		rs.close();
		stmt.close();
		
		return list;
	}
	
	
}
