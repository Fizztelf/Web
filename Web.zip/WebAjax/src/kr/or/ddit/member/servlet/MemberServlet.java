package kr.or.ddit.member.servlet;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.base.vo.BaseVO;

//import org.apache.commons.beanutils.BeanUtils;

import kr.or.ddit.member.service.MemberService;
import kr.or.ddit.member.vo.MemberVO;

@WebServlet("/MemberServlet")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 7428836381231581524L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		retrieveMemberList(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String action = request.getParameter("action");
		if("R".equals(action)) {
			retrieveMember(request, response);
			return;
		} else {
			retrieveMemberList(request, response);
		}
		
	}
	
	private void retrieveMemberList(HttpServletRequest request, HttpServletResponse response) {
		try {
			MemberVO memberVo = new MemberVO();
			memberVo.setMemId(request.getParameter("memId"));
			memberVo.setMemName(request.getParameter("memName"));
			
			MemberService service = new MemberService();
			Map<Object, Object> resultMap = service.retrieveMemberList(memberVo);
			
			@SuppressWarnings("unchecked")
			List<MemberVO> list = (List<MemberVO>) resultMap.get("list");
			request.setAttribute("list", list);
			
			int count = (int) resultMap.get("count");
			request.setAttribute("count", count);
			
			RequestDispatcher  disp = request.getRequestDispatcher("html/member/memberList.jsp");
			disp.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void retrieveMember(HttpServletRequest request, HttpServletResponse response) {
		try {
			String memId = request.getParameter("memId");
			String viewType = request.getParameter("viewType");
			
			MemberService service = new MemberService();
			MemberVO resultVo = service.retrieveMember(memId);
			
			request.setAttribute("memberVo", resultVo);
			
			String url = "";
			if("EDIT".equals(viewType)) {
				url = "html/member/memberEdit.jsp";
			} else {
				url = "html/member/memberView.jsp";
			} 
			
			RequestDispatcher  disp 
				= request.getRequestDispatcher(url);
			disp.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

//try {
//BeanUtils.populate(memberVo, request.getParameterMap());
//} catch (IllegalAccessException | InvocationTargetException e) {
//// TODO Auto-generated catch block
//e.printStackTrace();
//}
