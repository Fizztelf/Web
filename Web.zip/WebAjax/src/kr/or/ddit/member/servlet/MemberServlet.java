package kr.or.ddit.member.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.commons.beanutils.BeanUtils;

import kr.or.ddit.member.service.MemberService;
import kr.or.ddit.member.vo.MemberVo;

@WebServlet("/MemberServlet")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 7428836381231581524L;
	
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		int seq = Integer.parseInt(request.getParameter("seq"));
//		MemberService service = MemberService.getInstance();
//		MemberVo  vo =  service.selectView(seq);
//		
//		 request.setAttribute("vo", vo);
//		 RequestDispatcher  disp = request.getRequestDispatcher("html/member/member_list.jsp");
//		 disp.forward(request, response);
//		
//	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		MemberVo memberVo = new MemberVo();
//		try {
//			BeanUtils.populate(memberVo, request.getParameterMap());
//		} catch (IllegalAccessException | InvocationTargetException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		String action = request.getParameter("action");
		switch(action) {
		case "C":
			createMember(request, response, memberVo);
		case "R":
			retrieveMember(request, response, memberVo);
		case "U":
			retrieveMember(request, response, memberVo);
		case "D":
			retrieveMember(request, response, memberVo);
		default:
			retrieveMemberList(request, response, memberVo);
		}
		
	}
	
	private void createMember(HttpServletRequest request, HttpServletResponse response, MemberVo memberVo) {
		MemberService service = new MemberService();
		MemberVo resultVo = null;
		try {
			resultVo = service.createMember(memberVo);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		request.setAttribute("memberVo", resultVo);
		RequestDispatcher  disp = request.getRequestDispatcher("html/member/member_list.jsp");
		try {
			disp.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void retrieveMemberList(HttpServletRequest request, HttpServletResponse response, MemberVo memberVo) {
		memberVo.setId(request.getParameter("id"));
		memberVo.setName(request.getParameter("name"));
		
		List<MemberVo> resultList = new ArrayList<MemberVo>();
		try {
			MemberService service = new MemberService();
			resultList = service.retrieveMemberList(memberVo);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		request.setAttribute("memberVoList", resultList);
		RequestDispatcher  disp = request.getRequestDispatcher("html/member/member_list.jsp");
		try {
			disp.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void retrieveMember(HttpServletRequest request, HttpServletResponse response, MemberVo memberVo) {
		MemberService service = new MemberService();
		MemberVo resultVo = service.retrieveMember(memberVo);
		
		request.setAttribute("memberVo", resultVo);
		RequestDispatcher  disp = request.getRequestDispatcher("0108_arcodian/update.jsp");
		try {
			disp.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
