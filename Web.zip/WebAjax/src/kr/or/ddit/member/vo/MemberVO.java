package kr.or.ddit.member.vo;

public class MemberVO {
	
	private String memid;
	private String mempass;
	private String memname;
	private String memregno1;
	private String memregno2;
	private String membir;
	private String memzip;
	private String memaddr1;
	private String memaddr2;
	private String memhometel;
	private String memcomtel;
	private String memhp;
	private String memmail;
	private String memjob;
	private String memlike;
	private String memmemorial;
	private String memmemorialday;
	private String memmileage;
	private String memdelete;
	
	public MemberVO() {
		
	}

	public String getMemid() {
		return memid;
	}

	public void setMemid(String memid) {
		this.memid = memid;
	}

	public String getMempass() {
		return mempass;
	}

	public void setMempass(String mempass) {
		this.mempass = mempass;
	}

	public String getMemname() {
		return memname;
	}

	public void setMemname(String memname) {
		this.memname = memname;
	}

	public String getMemregno1() {
		return memregno1;
	}

	public void setMemregno1(String memregno1) {
		this.memregno1 = memregno1;
	}

	public String getMemregno2() {
		return memregno2;
	}

	public void setMemregno2(String memregno2) {
		this.memregno2 = memregno2;
	}

	public String getMembir() {
		return membir;
	}

	public void setMembir(String membir) {
		this.membir = membir;
	}

	public String getMemzip() {
		return memzip;
	}

	public void setMemzip(String memzip) {
		this.memzip = memzip;
	}

	public String getMemaddr1() {
		return memaddr1;
	}

	public void setMemaddr1(String memaddr1) {
		this.memaddr1 = memaddr1;
	}

	public String getMemaddr2() {
		return memaddr2;
	}

	public void setMemaddr2(String memaddr2) {
		this.memaddr2 = memaddr2;
	}

	public String getMemhometel() {
		return memhometel;
	}

	public void setMemhometel(String memhometel) {
		this.memhometel = memhometel;
	}

	public String getMemcomtel() {
		return memcomtel;
	}

	public void setMemcomtel(String memcomtel) {
		this.memcomtel = memcomtel;
	}

	public String getMemhp() {
		return memhp;
	}

	public void setMemhp(String memhp) {
		this.memhp = memhp;
	}

	public String getMemmail() {
		return memmail;
	}

	public void setMemmail(String memmail) {
		this.memmail = memmail;
	}

	public String getMemjob() {
		return memjob;
	}

	public void setMemjob(String memjob) {
		this.memjob = memjob;
	}

	public String getMemlike() {
		return memlike;
	}

	public void setMemlike(String memlike) {
		this.memlike = memlike;
	}

	public String getMemmemorial() {
		return memmemorial;
	}

	public void setMemmemorial(String memmemorial) {
		this.memmemorial = memmemorial;
	}

	public String getMemmemorialday() {
		return memmemorialday;
	}

	public void setMemmemorialday(String memmemorialday) {
		this.memmemorialday = memmemorialday;
	}

	public String getMemmileage() {
		return memmileage;
	}

	public void setMemmileage(String memmileage) {
		this.memmileage = memmileage;
	}

	public String getMemdelete() {
		return memdelete;
	}

	public void setMemdelete(String memdelete) {
		this.memdelete = memdelete;
	}

	public MemberVO(String memid, String mempass, String memname, String memregno1, String memregno2, String membir,
			String memzip, String memaddr1, String memaddr2, String memhometel, String memcomtel, String memhp,
			String memmail, String memjob, String memlike, String memmemorial, String memmemorialday, String memmileage,
			String memdelete) {
		super();
		this.memid = memid;
		this.mempass = mempass;
		this.memname = memname;
		this.memregno1 = memregno1;
		this.memregno2 = memregno2;
		this.membir = membir;
		this.memzip = memzip;
		this.memaddr1 = memaddr1;
		this.memaddr2 = memaddr2;
		this.memhometel = memhometel;
		this.memcomtel = memcomtel;
		this.memhp = memhp;
		this.memmail = memmail;
		this.memjob = memjob;
		this.memlike = memlike;
		this.memmemorial = memmemorial;
		this.memmemorialday = memmemorialday;
		this.memmileage = memmileage;
		this.memdelete = memdelete;
	}

	

	
}
