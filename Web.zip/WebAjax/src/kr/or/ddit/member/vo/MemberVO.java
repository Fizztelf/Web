package kr.or.ddit.member.vo;

public class MemberVO {
	
	private String memid;
	private String mempass;
	private String memname;
	private String memregno1;
	private String memregno2;
	private String membir;
	private String memzip;
	private String memadd1;
	private String memadd2;
	private String memhometel;
	private String memcomtel;
	private String memhp;
	private String memmail;
	private String memjob;
	private String memlike;
	private String memmemorial;
	private String memmemorialday;
	private String memmileage;
	private String memdelete;
	
	public MemberVO() {
		
	}

	public String getMemid() {
		return memid;
	}

	public void setMemid(String memid) {
		this.memid = memid;
	}

	public String getMempass() {
		return mempass;
	}

	public void setMempass(String mempass) {
		this.mempass = mempass;
	}

	public String getMemname() {
		return memname;
	}

	public void setMemname(String memname) {
		this.memname = memname;
	}

	public String getMemregno1() {
		return memregno1;
	}

	public void setMemregno1(String memregno1) {
		this.memregno1 = memregno1;
	}

	public String getMemregno2() {
		return memregno2;
	}

	public void setMemregno2(String memregno2) {
		this.memregno2 = memregno2;
	}

	public String getMembir() {
		return membir;
	}

	public void setMembir(String membir) {
		this.membir = membir;
	}

	public String getMemzip() {
		return memzip;
	}

	public void setMemzip(String memzip) {
		this.memzip = memzip;
	}

	public String getMemadd1() {
		return memadd1;
	}

	public void setMemadd1(String memadd1) {
		this.memadd1 = memadd1;
	}

	public String getMemadd2() {
		return memadd2;
	}

	public void setMemadd2(String memadd2) {
		this.memadd2 = memadd2;
	}

	public String getMemhometel() {
		return memhometel;
	}

	public void setMemhometel(String memhometel) {
		this.memhometel = memhometel;
	}

	public String getMemcomtel() {
		return memcomtel;
	}

	public void setMemcomtel(String memcomtel) {
		this.memcomtel = memcomtel;
	}

	public String getMemhp() {
		return memhp;
	}

	public void setMemhp(String memhp) {
		this.memhp = memhp;
	}

	public String getMemmail() {
		return memmail;
	}

	public void setMemmail(String memmail) {
		this.memmail = memmail;
	}

	public String getMemjob() {
		return memjob;
	}

	public void setMemjob(String memjob) {
		this.memjob = memjob;
	}

	public String getMemlike() {
		return memlike;
	}

	public void setMemlike(String memlike) {
		this.memlike = memlike;
	}

	public String getMemmemorial() {
		return memmemorial;
	}

	public void setMemmemorial(String memmemorial) {
		this.memmemorial = memmemorial;
	}

	public String getMemmemorialday() {
		return memmemorialday;
	}

	public void setMemmemorialday(String memmemorialday) {
		this.memmemorialday = memmemorialday;
	}

	public String getMemmileage() {
		return memmileage;
	}

	public void setMemmileage(String memmileage) {
		this.memmileage = memmileage;
	}

	public String getMemdelete() {
		return memdelete;
	}

	public void setMemdelete(String memdelete) {
		this.memdelete = memdelete;
	}

	@Override
	public String toString() {
		return "MemberVO [memid=" + memid + ", mempass=" + mempass + ", memname=" + memname + ", memregno1=" + memregno1
				+ ", memregno2=" + memregno2 + ", membir=" + membir + ", memzip=" + memzip + ", memadd1=" + memadd1
				+ ", memadd2=" + memadd2 + ", memhometel=" + memhometel + ", memcomtel=" + memcomtel + ", memhp="
				+ memhp + ", memmail=" + memmail + ", memjob=" + memjob + ", memlike=" + memlike + ", memmemorial="
				+ memmemorial + ", memmemorialday=" + memmemorialday + ", memmileage=" + memmileage + ", memdelete="
				+ memdelete + "]";
	}

	public MemberVO(String memid, String mempass, String memname, String memregno1, String memregno2, String membir,
			String memzip, String memadd1, String memadd2, String memhometel, String memcomtel, String memhp,
			String memmail, String memjob, String memlike, String memmemorial, String memmemorialday, String memmileage,
			String memdelete) {
		super();
		this.memid = memid;
		this.mempass = mempass;
		this.memname = memname;
		this.memregno1 = memregno1;
		this.memregno2 = memregno2;
		this.membir = membir;
		this.memzip = memzip;
		this.memadd1 = memadd1;
		this.memadd2 = memadd2;
		this.memhometel = memhometel;
		this.memcomtel = memcomtel;
		this.memhp = memhp;
		this.memmail = memmail;
		this.memjob = memjob;
		this.memlike = memlike;
		this.memmemorial = memmemorial;
		this.memmemorialday = memmemorialday;
		this.memmileage = memmileage;
		this.memdelete = memdelete;
	}
	

	
}
