package kr.or.ddit.member.service;

import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.member.dao.MemberDao_1023;
import kr.or.ddit.member.vo.MemberVO;

public class MemberService {
	private MemberDao_1023 dao;
	
	public MemberService() {
		if(dao == null)
			dao = new MemberDao_1023();
	}
	
	public MemberVO createMember(MemberVO memberVo) throws Exception {
		int result = dao.createMember(memberVo);
//		if(result > 0) {
//			MemberVO tmpMemberVo = new MemberVO(mem_id, mem_pass, mem_name, mem_regno1, mem_regno2, mem_bir, mem_zip, mem_add1, mem_add2, mem_hometel, mem_comtel, mem_hp, mem_mail, mem_job, mem_like, mem_memorial, mem_memorialday, mem_mileage, mem_delete);
//			tmpMemberVo.setMEM_ID(memberVo.getmem_id());
//			return dao.retrieve(tmpMemberVo);
//		} else {
			return memberVo;
		}
//	}
	
	public MemberVO updateMember(MemberVO memberVo) {
//		return dao.memberVo;
		return memberVo;
	}
	public List<MemberVO> deleteMember(MemberVO memberVo) {
		return new ArrayList<MemberVO>();
	}
	public MemberVO retrieveMember(MemberVO memberVo) {
//		return dao.retrieveMember(memberVo);
		return new MemberVO();
	}
	public List<MemberVO> retrieveMemberList(MemberVO memberVo) throws Exception {
		return dao.retrieveList(memberVo);
//		return dao.tmpList();
	}
}
