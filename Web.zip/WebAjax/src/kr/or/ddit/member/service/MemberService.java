package kr.or.ddit.member.service;

import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.member.dao.MemberDao_1023;
import kr.or.ddit.member.vo.MemberVO;

public class MemberService {
	private MemberDao_1023 dao;
	
	public MemberService() {
		if(dao == null)
			dao = new MemberDao_1023();
	}
	
	public int createMember(MemberVO memberVo) throws Exception {
			return dao.createMember(memberVo);
	}
	
	public MemberVO updateMember(MemberVO memberVo) {
//		return dao.memberVo;
		return memberVo;
	}
	public List<MemberVO> deleteMember(MemberVO memberVo) {
		return new ArrayList<MemberVO>();
	}
	public MemberVO retrieveMember(MemberVO memberVo) {
//		return dao.retrieveMember(memberVo);
		return new MemberVO();
	}
	public List<MemberVO> retrieveMemberList(MemberVO memberVo) throws Exception {
		return dao.retrieveList(memberVo);
//		return dao.tmpList();
	}
	

	
}
