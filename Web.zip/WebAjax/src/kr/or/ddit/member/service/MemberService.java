package kr.or.ddit.member.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.or.ddit.member.dao.MemberDao;
import kr.or.ddit.member.vo.MemberVO;

public class MemberService {
	private MemberDao dao;
	
	public MemberService() {
		if(dao == null)
			dao = new MemberDao();
	}
	
	public MemberVO retrieveMember(String memId) throws Exception {
		return dao.retrieveMember(memId);
	}
	
	public Map<Object, Object> retrieveMemberList(MemberVO memberVo) throws Exception {
		List<MemberVO> list = dao.retrieveMemberList(memberVo);
		int count = dao.retrieveMemberListCount(memberVo);
		
		Map<Object, Object> resultMap = new HashMap<>();
		resultMap.put("list", list);
		resultMap.put("count", count);
		
		return resultMap;
	}
	
}
