package kr.or.ddit.common;

public class MyUtill {
/**
 * 빈 값이면 true를 반환, 아니면 false 반환
 * @param str
 * @return
 */
	public static boolean isEmpty() {
//		if(str == null) {
//			
//		}
		return true;
	}
}
