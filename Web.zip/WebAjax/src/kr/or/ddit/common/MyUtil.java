package kr.or.ddit.common;

public class MyUtil {
	/**
	 * 빈값이면 true를 반환. 아니면 false 반환
	 * @param str
	 * @return
	 */
	public static boolean isEmpty(String str) {
		if(str == null)
			return true;
		
		str = str.trim();
		if(str.length() == 0)
			return true;
		
		return false;
	}
}
