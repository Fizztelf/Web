package kr.or.ddit.member.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.media.sound.RealTimeSequencerProvider;

import kr.or.ddit.member.dao.MemberDaoimpl;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceimpl;
import kr.or.ddit.member.vo.ZipVO;

/**
 * Servlet implementation class SearchDong
 */
@WebServlet("/SearchAddr")
public class SearchAddr extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchAddr() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// doPost일때는 인코딩 처리를 해줘야한다. (doGet에서는 안해도된다.)
		request.setCharacterEncoding("utf-8");
		String inputDong = request.getParameter("dong");
		
		//2. service 객체 얻어오기
		IMemberService service = MemberServiceimpl.getService();
		
		//3. 메소드 호출
		List<ZipVO> list = service.selectByDong(inputDong);
		
		//4. request에 저장
		request.setAttribute("list", list);
		
		//5. jsp
		request.getRequestDispatcher("tbmember/addrForm.jsp").forward(request, response);
	}

}
