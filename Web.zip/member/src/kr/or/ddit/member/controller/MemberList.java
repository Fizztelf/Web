package kr.or.ddit.member.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceimpl;
import kr.or.ddit.member.vo.MemberVO;

/**
 * Servlet implementation class MemberList
 */
@WebServlet("/List.do")
public class MemberList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberList() {
        super();
        // TODO Auto-generated constructor stub
    }

    // request는 페이지 한번 넘어가면 끝
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setCharacterEncoding("UTF-8");
		
		// 1. 클라이언트 요청시 전달되는 데이터를 받는다
		

		// 2. 1번에서 받은 데이터를 가지고  DB를 통해서 CRUD 작업이 이루어진다. 
		// - service객체 얻어온다.
		IMemberService service = MemberServiceimpl.getService();
		
		// - 결과값변수 = Service메소드 호출
		List<MemberVO> list = service.selectAll();
		
		// 3. CRUD결과를 Request에 저장한다 -> 여기서 set한걸 foward에서 get함 
		request.setAttribute("list", list);

		// 4. CRUD작업의 결과를 가지고 VIEW페이지 JSP로 이동 -> jsp페이지에서 출력
		//★jsp페이지로 이동하는 방법★
		// 데이터의 공유 유/무 
		// forward => 컨트롤러에서 가지고있는 결과값을 jsp에서 공유할수 잇다. request, application, session
		// 			   컨트롤러의 request와 view의 request가 공유한다. -> view페이지가 꺼내서 쓴다.
		// redirect => 컨트롤러에서 jsp로 갔다가 다시 view로 보내는것. 클라이언트가 보낸 결과값(controller의 request)은 사라짐 -> 공유불가
		
		request.getRequestDispatcher("tbmember/member.jsp").forward(request, response);
		
		// 404 -> html의 url오류 or servlet의 dispatcher 오류
	}

}
