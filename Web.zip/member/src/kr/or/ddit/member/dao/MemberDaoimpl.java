package kr.or.ddit.member.dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.ibatis.config.SqlMapClientFactory;
import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.member.vo.ZipVO;

/*
  	Mapper sql문을 수행 -> SqlMpclient 객체가 필요
 	자신의 객체를 생성해서 리턴 시킨다. -> sevice에서 사용
 */
public class MemberDaoimpl implements IMemberDao {
	
	private SqlMapClient smc;
	private static IMemberDao dao;
	
	private MemberDaoimpl() { //service에서 사용하지 못하게 하도록 private으로 사용
		smc = SqlMapClientFactory.getClient();
	}
	
	public static IMemberDao getDao() { // dao가 없을때만 호출 있으면 리턴
		if(dao == null) {
			dao = new MemberDaoimpl();			
		}
		return dao;
	}
	
	@Override
	public List<MemberVO> selectAll() throws SQLException  {
		
		return smc.queryForList("member.selectAll");
	}

	
	
	
	
	@Override
	public String checkById(String id) throws SQLException {
		
		return (String)smc.queryForObject("memzip.checkById", id);
	}

	@Override
	public List<ZipVO> selectByDong(String dong) throws SQLException {
		
		return smc.queryForList("memzip.selectByDong", dong);
	}

	@Override
	public String insertMember(MemberVO vo) throws SQLException {
		
		return (String)smc.insert("memzip.insertMember",vo);
	}


}
