package kr.or.ddit.common.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import kr.or.ddit.common.service.CodeService;
import kr.or.ddit.common.service.ZipService;
import kr.or.ddit.member.vo.ZipVO;

/**
 * 주소 담당 서블릿
 * 2020년 10월 30일 금요일
 */
@WebServlet("/ZipServlet")
public class ZipServlet extends HttpServlet {
	private static final long serialVersionUID = 7428836381231581524L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		retrieveZipList(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		retrieveZipList(request, response);
		
	}
	
	private void retrieveZipList(HttpServletRequest request, HttpServletResponse response) {
		try {
			String sido = request.getParameter("chkPlace");
			
			ZipVO zipVo = new ZipVO();
			BeanUtils.populate(zipVo, request.getParameterMap());

			ZipService service = new ZipService();
			List<ZipVO> list = new ArrayList<ZipVO>();
			if("SIDO".equals(sido)) {
				list = service.retrieveSidoList();
			}
			else if("GUGUN".equals(sido)) {
				list = service.retrieveGugunList(zipVo);
			}
			else if("DONG".equals(sido)) {
				list = service.retrieveDongList(zipVo);
			
			} else {
				list = service.retrieveZipcodeList(zipVo);
			}
			
			request.setAttribute("list", list);
			
			RequestDispatcher  disp = request.getRequestDispatcher("/tbmember/zipList.jsp");
			disp.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
