package kr.or.ddit.common.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.common.service.CodeService;
import kr.or.ddit.common.vo.CodeVO;

@WebServlet("/CodeServlet")
public class CodeServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		retrieveCodeList(req, resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		retrieveCodeList(req, resp);
		
	}
	
	private void retrieveCodeList(HttpServletRequest request, HttpServletResponse response) {
		try {
			CodeVO codeVo = new CodeVO();
			codeVo.setGroupCode(request.getParameter("groupCode"));
			
			CodeService service = new CodeService();
			
			List<CodeVO> list = service.retrieveCodeList(codeVo);
			
			request.setAttribute("list", list);
			
			RequestDispatcher disp = request.getRequestDispatcher("/tbmember/codeList.jsp");
			disp.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}