package kr.or.ddit.common.service;

import java.util.List;

import kr.or.ddit.common.dao.CodeDao;
import kr.or.ddit.common.vo.CodeVO;

public class CodeService {
	private static CodeDao dao;
	
	public CodeService() {
		if(dao == null)
			dao = new CodeDao();
	}
	
	public List<CodeVO> retrieveCodeList(CodeVO codeVo) throws Exception {
		return dao.retrieveCodeList(codeVo);
	}
	
	public static void main(String args[]) {
		try {
			dao = new CodeDao();
			List<String> list = retrieveSidoList();
			System.out.println(list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static List<String> retrieveSidoList() {
		// TODO Auto-generated method stub
		return null;
	}
}


