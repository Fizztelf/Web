package kr.or.ddit.common.service;

import java.util.List;

import kr.or.ddit.common.dao.CodeDao;
import kr.or.ddit.common.dao.ZipDao;
import kr.or.ddit.common.vo.CodeVO;
import kr.or.ddit.member.vo.ZipVO;

public class ZipService {
	private ZipDao dao;
	
	public ZipService() {
		if(dao == null)
			dao = new ZipDao();
	}

	public List<ZipVO> retrieveZipcodeList(ZipVO zipVo) throws Exception {
		return dao.retrieveZipcodeList(zipVo);
	}
	public List<ZipVO> retrieveSidoList() throws Exception {
		return dao.retrieveSidoList();
	}
	public List<ZipVO> retrieveGugunList(ZipVO zipVo) throws Exception {
		return dao.retrieveGugunList(zipVo);
	}
	public List<ZipVO> retrieveDongList(ZipVO zipVo) throws Exception {
		return dao.retrieveDongList(zipVo);
	}
	
}
