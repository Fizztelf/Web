package kr.or.ddit.common.dao;

import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.base.dao.BaseDao;
import kr.or.ddit.common.vo.CodeVO;
import kr.or.ddit.member.vo.ZipVO;

public class ZipDao extends BaseDao{
	
	private SqlMapClient smc;

	public ZipDao() {
		smc = super.getSqlMapClient();
	}
	
	public List<ZipVO> retrieveSidoList() throws Exception {
		List<ZipVO> list = new ArrayList<>();
		list = smc.queryForList("code.retrieveSidoList");
		return list;
	}
	
	public List<ZipVO> retrieveGugunList(ZipVO zipVo) throws Exception {
		List<ZipVO> list = new ArrayList<>();
		list = smc.queryForList("code.retrieveGugunList", zipVo);
		return list;
	}
	
	public List<ZipVO> retrieveDongList(ZipVO zipVo) throws Exception {
		List<ZipVO> list = new ArrayList<>();
		list = smc.queryForList("code.retrieveDONGList", zipVo);
		return list;
	}
	
	public List<ZipVO> retrieveZipcodeList(ZipVO zipVo) throws Exception {
		List<ZipVO> list = new ArrayList<>();
		list = smc.queryForList("code.retrieveZipcodeList", zipVo);
		return list;
	}


}
