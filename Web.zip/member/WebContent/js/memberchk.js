/**
 * 
 */

// idchk = function(){}
// 아래와 같은 함수 표기법
function idchk(){
	
	// 입력한 id값 가져오기
	idvalue = $('#id').val().trim();
	
	if(idvalue.length < 1){
		alert("id를 입력하세요.");
		return false;
	}
	
	return true;
}
