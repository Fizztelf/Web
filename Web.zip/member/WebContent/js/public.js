/**
 * 멤멤
 */

$(document).ready(function(){
	
	like();
	Job();
	
	
	
	
		// 중복된 아이디 확인
		$('#idchk').on('click', function(){
			if(Check() == false){ // id 입력한 값이 없을때
				return false;
			} 
				$.ajax({
					url : '/IdCheck'
					,type : 'GET'
					,dataType : 'json'
					,data : { "id" : idvalue }
					,success : function(res){
						result(res);
					}
					,error : function(xhr){
						alert("상태 : " + xhr.statuss);
					}
				});
		});
		
//		function result(res){
//			var re = res.id;
//			var ress = res.idchk;
//			if(ress == 1) { // 값이 있음, 중복
//				$('#idspan').html(re).css('color', 'red');
//			} else if(ress == 2) { // 값이 없음, 사용가능
//				$('#idspan').html(re).css('color', 'blue');
//			}
//		}
		function result(res){
			var re = res.id;
			if(re == 1) { // 값이 있음, 중복
				alert("중복된 아이디입니다.");
			} else if(re == 2) { // 값이 없음, 사용가능
				alert("사용 가능한 아이디입니다.");
			}
		}
		
		
		
		function Check(){
			idvalue = $('#id').val().trim();
			if(idvalue.length < 1){
				alert("ID를 입력하시지 않았습니다.");
				return false;
			}
			return true;
		}
		
		
// 		$('#chk').on('click',function(){
			
// 			if(chk()== false){
// 				return false;
// 			}
// // 			var id = $('#id').val();
			
// 			$.ajax({
// 				url : "/IdCheck"
// 				, type : 'GET'
// 				, data : {"id" : idvalue}
// 				, dataType : "json"
// 				, success : function(data) {
// 					if(data.cnt > 0){
// 						$('#msg').html("중복된 아이디 입니다").css('color', 'red');
// 					} else {
// 						$('#msg').html("사용가능한 아이디 입니다").css('color', 'blue');
// 						// 아이디가 중복하지 않으면 idck = 1
// 						idck = 1;
// 					}
// 				}
// 				, error : function(error){
// 					alter("error : " + error);
// 				}
// 			});
// 		});
		
		
		
		// 번호 검색 버튼 클릭시 modal창 띄우기 - 이벤트 별도로 등록하지 않는다.
		$('#sendbtn').on('click',function(){
			idvalue = $('#id').val();
		
			info = $('#joinform').serializeArray();
			console.log(info);
			
			test();
			
			$.ajax({
				url : '/InsertSignUp',	
				type : 'post',				
				data : info,
				dataType : 'json',
				
				success : function(res){
					$('#resetbtn').hide();
					
					send(res);
					
//					$('#sendspan').html(idvalue + res.sw).css('color','red');
				},
				error : function(xhr){
					alert("상태 : " + xhr.status);
				},
			});
			
		});
		
		function send(res){
			var result = res.id;
			if(result == 1){
				alert(idvalue+"님 안녕하세요.");
			} else if(result == 2){
				alert("가입에 실패하셨습니다.");
			}
		}
		
		
		function test(){
			if($('#id').val()==""){
				alert("아이디를 입력해주세요");
				$('#id').focus();
				return;
			}
			
			if($('#pass').val()==""){
				alert("비밀번호를 입력해주세요");
				$('#pass').focus();
				return;
			}
			
			if($('#pass2').val()==""){
				alert("비밀번호 재입력도 하셔야해요");
				$('#pass2').focus();
				return;
			}
			
			if($('#name').val()==""){
				alert("이름을 입력해주세요");
				$('#name').focus();
				return;
			}
			
			if($('#bir').val()==""){
				alert("생년월일을 입력해주세요");
				$('#bir').focus();
				return;
			}
			
			if($('#hp').val()==""){
				alert("전화번호를 입력해주세요");
				$('#hp').focus();
				return;
			}
			if($('#mail').val()==""){
				alert("이메일을 입력해주세요");
				$('#mail').focus();
				return;
			}
			
			if($('#gen option:selected').val()==""){
				alert("성별을 선택해주세요");
				$('#gen option:selected').focus();
				return;
			}
				
			
		}
		
		
		
		
		// 모달창에서 동이름 입력하고 확인버튼 클릭할때
		$('#zipchk').on('click', function(){
			 dongvalue = $('#dong').val();
				
			 $.ajax({
				 url : '/SearchAddr',
				 type : 'post',
				 data : {'dong' : dongvalue},
				 dataType : 'json',
				 success : function(res){
					 code = "<table border = 3>";
					 code += "<tr><td>우편번호</td><td>주소</td><td>번지</td></tr>";
					 $.each(res, function(i,v){
						 code += "<tr class = 'ziptr'><td>"+v.zipcode+"</td><td>"+v.addr+"</td><td>"+v.bunji+"</td></tr>";
					 });
					 code += "</table>";
					 $('#result1').html(code);
				 },
				 error : function(xhr){
					 alert("상태 : " + xhr.status);
				 }
			 });
		});
		
		// 우편번호 검색의 실행결과에서 원하는 하나의 행을 선택하면 
		$('#result1').on('click', '.ziptr', function(){
			 // this는 ziptr이다. this에 포함되어있는 td:eq(0) 
			 zipcode = $('td:eq(0)',this).text();
			 addr = $('td:eq(1)', this).text(); //클릭한 주소를 가져온다.
			 
			 $('#zip').val(zipcode);
			 $('#add1').val(addr);
			 
			 $("#myModal").modal("hide");
	
		 });
		 
		 // modal창 닫기 이벤트 - 닫기라는 이벤트 발생할때 기존의 결과값을 지운다.
		 $('#myModal').on('hide.bs.modal', function(){
			 $('#result1').empty();
			 $('#dong').val(""); // input일때는 val
		 });
		
	});
	
	
	
	
	function like(){
		$.ajax({
			url : "/CodeServlet"
			, type : "POST"
			, data : { "groupCode" : "A01"}
			, dataType : "Json"
			, success : function(data) {
				selectLike(data);
			} 
			, error : function(xhr){
				alert("상태 : " + xhr.status);
			}
		});
	}
	
	function selectLike(data) {
		var like ="";
		for(var i=0; i<data.length; i++){
			like += '<option value="'+data[i].code+'">'+data[i].name+'</option>';
		}
		$("#memlike").html(like);
	}
	
	//직업
	function Job(){
		$.ajax({
			url:'/CodeServlet'
			,type:'post'
			,data:{"groupCode":"A02"}
			,dataType:"json"	
			,success:function(data){
				selectJob(data);
			}
			,error:function(xhr){
				alert("상태 : " + xhr.status);
			}                       
		});
	}

	function selectJob(data){
		var job="";
		for(var i=0; i<data.length; i++){
			job += '<option value="'+data[i].code+'">'+data[i].name+'</option>';
		}
		$("#memJob").html(job);
	}

	// 아이디 정규식 체크
	function idCheck(){
		id = $('#id').val();
		var idcheck = RegExp(/^[A-Za-z][A-Za-z0-9]{4,12}$/);
		if (idcheck.test(id) == false) {
			$('#idspan1').html("Nope!").css('color', 'red');
			return false;
		}else{
			$('#idspan1').html("Good!").css('color','blue');
			return true;
		}
	}
	
	// 이름 정규식 체크
	function nameCheck(){
		name = $('#name').val();
		var namecheck = RegExp(/[가-힣]{2,5}$/);	 
		if (namecheck.test(name) == false) {
			$('#namespan').html("Nope!").css('color', 'red');
		}else{
			$('#namespan').html("Good").css('color', 'blue');
		}	
	}
	
	
	
	
	// 이메일 정규식 체크
	function mailCheck(){
		mail = $('#mail').val();
		var mailcheck = RegExp(/^[A-Za-z0-9_\.\-]+@[A-Za-z0-9\-]+\.[A-Za-z0-9\-]+/);	 
		if (mailcheck.test(mail) == false) {
			$('#mailspan').html("Nope!").css('color', 'red');
		}else{
			$('#mailspan').html("Good!").css('color', 'blue');
		}
	}
	
	// 전화번호 정규식 체크
	function hpCheck(){
		hp = $('#hp').val();
		var hpcheck = RegExp(/^01[0179]-[0-9]{4}-[0-9]{4}$/);
		if (hpcheck.test(hp) == false) {
			$('#telspan').html("Nope!").css('color', 'red');
		}else{
			$('#telspan').html("Good!").css('color', 'blue');
		}
	}
	
	// 비밀번호 정규식 체크
	function pwCheck(){
		pw = $('#pass').val();
		var pwcheck = RegExp(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,15}$/);
		if (pwcheck.test(pw) == false) {
			$('#pwspan').html("Nope!").css('color', 'red');
		} else {
			$('#pwspan').html("Good!").css('color', 'blue');
		}
	}
	
	
	// 비밀번호 확인 체크
	function pw2Check(){
		pw2 = $('#pass2').val();
		if (pw != pw2) {
			$('#pwspan2').html("불일치").css('color', 'red');
		} else{
			$('#pwspan2').html("일치").css('color','blue');
		}
	}
	
	
	// 성별 체크
	function genCheck(){
		if ($('#gen option:selected').val() == "") {
			$('#genspan').html("선택하세요").css('color', 'red');
		} 
		
		if($('#gen option:selected').val() == "여성"){
			$('#genspan').html("여성분이시군요").css('color','blue');
		} else if($('#gen option:selected').val() == "남성"){
			$('#genspan').html("남성분이시군요").css('color','blue');
		}
	}
	
	
//	function age(){
//		var input = $('#bir').val();
//		var bir = ParseInt(input.substr(0,4));
//		
//		var age = ParseInt((new Date).getFullYear()) - bir + 1;
//		alert(age);
//	}
 	function doOpenCheck(chk){
 	    var obj = document.getElementsByName("recv_email_yn");
// 	    var obj1 = $('input:checkbox[id="recv_email_yn"]').val();
// 	    var emailChk = document.getElementsByName("recv_email_yn").length;
 	    for(var i=0; i<obj.length; i++){
 	        if(obj[i] != chk){
 	            obj[i].checked = false;
 	        }
 	    }
// 	    for(var j=0; j<emailChk; j++){
// 	    	if(document.getElementsByName("recv_email_yn")[j].checked==true){
// 	    		alert(document.getElementsByName("recv_email_yn")[j].val);
// 	    	}
// 	    }
 	}
	
 	// 광고성 이메일 체크
// 	$('input:checkbox[id="recv_email_yn"]').val();
 	
//	function emailCheck(chk){
//		var obj =$(document).getElementByName("recv_email_yn");
//		for(var i=0; i<obj.length; i++){
//			if(obj[i] != chk){
//				obj[i].checked = false;
//			}
//		}
//	}
	
	function join(){
		genCheck();
// 		jobCheck();
	}